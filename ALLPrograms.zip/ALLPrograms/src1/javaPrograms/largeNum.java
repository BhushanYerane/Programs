package javaPrograms;

import java.util.Arrays;

import coreJavaz.Collections.new25.MemoryManager;

public class largeNum {

	public static void main(String[] args) {

		double numArry[] = { 12, 45, 98, -36.5, 37.89, -99.25, 100 };
		double smalnum = numArry[0];
		double largnum = numArry[0];

		for (int i = 0; i < numArry.length; i++) {
			if (numArry[i] > largnum) {
				largnum = numArry[i];
			} else if (numArry[i] < smalnum) {
				smalnum = numArry[i];
			}
		}
		System.out.println("Smallest Number is : " + smalnum);
		System.out.println("Largest Number is : " + largnum);

		// Without Sort Smallest
		double smallest = Double.MAX_VALUE;
		double secondSmallest = Double.MAX_VALUE;
		for (double num : numArry) {
			if (num < smallest) {
				secondSmallest = smallest;
				smallest = num;
			} else if (num < secondSmallest && num != smallest) {
				secondSmallest = num;
			}
		}
		System.out.println("Second Smallest Number (without sort): " + secondSmallest);

		// Without Sort Smallest
		Arrays.sort(numArry);
		double secondSmallest1 = numArry[1];
		System.out.println("Second Smallest Number (with sort): " + secondSmallest1);

		// Second largest number and without Sort
		double largest = Double.MIN_VALUE;
		double secondLargest = Double.MIN_VALUE;
		for (double num : numArry) {
			if (num > largest) {
				secondLargest = largest;
				largest = num;
			} else if (num > secondLargest && num != largest) {
				secondLargest = num;
			}
		}
		System.out.println("Second Largest Number (without sort): " + secondLargest);

		// Second largest number and with Sort
		Arrays.sort(numArry);
		for (double n : numArry) {
			System.out.print(n + ", ");
		}
		System.out.println();

		// Find second largest number
		double secondLargest1 = numArry[numArry.length - 2];
		System.out.println("Second Largest Number is : " + secondLargest1);
		
		MemoryManager.cleanUp();
	}
}
