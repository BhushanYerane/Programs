package javaPrograms;

import java.util.List;

public class missingnum {
	/*
	 * error static int getmissingNo(int a[], int n) { int total = 1; for (int i =
	 * 2; i <= (n + 1); i++) { total = total + i; total = total - a[i - 2]; } return
	 * total; }
	 */
	

	public static int findDisappearedNumbers(int[] nums) {
		int n = nums.length;
		int sum = ((n + 1) * (n + 2)) / 2;
		for (int i = 0; i < n; i++)
			sum -= nums[i];
		return sum;
	}

	public static void main(String[] args) {

		/*
		 * errror int arr1[] = { 1, 2, 3, 4, 5, 8 };
		 * System.out.println(getmissingNo(arr1, arr1.length));
		 */
		int[] arr = { 1, 2, 3, 4, 5, 8 };
		List<Integer> missing = findMissingNumbers(arr);

		if (missing.isEmpty()) {
			System.out.println("No missing numbers.");
		} else {
			System.out.println("First missing number: " + missing.get(0));
			promptForFullList(missing);
		}

		System.out.println("//-------------------");

		int[] a = { 1, 2, 3, 4, 5, 7 };
		System.out.println(findDisappearedNumbers(a));

	}

	private static void promptForFullList(List<Integer> missing) {
		// TODO Auto-generated method stub
		
	}

	private static List<Integer> findMissingNumbers(int[] arr) {
		// TODO Auto-generated method stub
		return null;
	}
}
