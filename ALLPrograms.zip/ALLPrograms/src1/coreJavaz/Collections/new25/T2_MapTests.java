/*
 * https://www.programiz.com/java-programming/map
 * https://www.programiz.com/java-programming/library/hashmap
 * numMap for Interger varible
 * strMap for String
 * */
package coreJavaz.Collections.new25;

import java.util.*;
import java.util.Map.Entry;

public class T2_MapTests {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Map<String, List<String>> frameworks = new HashMap<>();

		frameworks.put("Java", Arrays.asList("JUnit", "TestNG", "Mockito", "Cucumber", "Rest Assured"));
		frameworks.put("Python", Arrays.asList("PyTest", "unittest", "nose2", "Behave", "Robot Framework"));
		frameworks.put("JavaScript", Arrays.asList("Jest", "Mocha", "Jasmine", "Cypress", "Playwright"));
		frameworks.put("C#", Arrays.asList("NUnit", "xUnit", "MSTest", "SpecFlow"));
		frameworks.put("Ruby", Arrays.asList("RSpec", "Cucumber", "Minitest"));
		frameworks.put("PHP", Arrays.asList("PHPUnit", "Codeception", "Behat"));
		frameworks.put("Go", Arrays.asList("Go testing", "Ginkgo", "Testify"));
		frameworks.put("Swift", Arrays.asList("XCTest", "Quick", "Nimble"));

		frameworks.forEach((language, tools) -> {
			System.out.println(language + ": " + tools);
		});
		System.out.println("<-------------------<-#$->------------------->");

		// Implementing HashMap Class
		Map<String, Integer> numMap1 = new HashMap<>();
		numMap1.put("First", 1); // put(K, V) - Inserts the association of a key K and a value V into the map. If
									// the key is already present, the new value replaces the old value.
		numMap1.put("Second", 2);
		numMap1.put("Three", 3);
		numMap1.put("Ninety Nine", 99);
		System.out.println("-# Map1 :" + numMap1);

		// Access keys of the map //- keySet() - Returns a set of all the keys present
		// in a map.
		Set<String> str1 = numMap1.keySet();
		// System.out.println("Keys-: "+ str1);
		System.out.println("Keys-: " + numMap1.keySet());

		// Access values of the map // - values() - Returns a set of all the values
		// present in a map.
		Collection<Integer> num1 = numMap1.values();
		// System.out.println("Values-: "+ num1);
		System.out.println("Values-: " + numMap1.values());

		// Access entries of the map // - entrySet() - Returns a set of all the
		// key/value mapping present in a map.
		System.out.println("Entries: " + numMap1.entrySet());

		// Remove Elements from the map
		int value = numMap1.remove("Ninety Nine");
		System.out.println("Removed Value: " + value);
		System.out.println("<-------------------<-#$->------------------->");

		// Clear() - // remove all mappings from HashMap
		HashMap<String, Integer> numMap2 = new HashMap<>();
		numMap2.put("One", 1);
		numMap2.put("Two", 2);
		numMap2.put("Three", 3);
		System.out.println("HashMap New: " + numMap2);

		numMap2.clear();
		System.out.println("HashMap Clear: " + numMap2);

		//// reinitialize the hashmap
		numMap2 = new HashMap<>();
		System.out.println("HashMap Reinitialize: " + numMap2);

		// Clone() - The clone() method does not take any parameters.
		HashMap<String, Integer> language1 = new HashMap<>();
		language1.put("Java", 14);
		language1.put("Python", 3);
		language1.put("JavaScript", 1);
		System.out.println("HashMap New : " + language1);

		language1.put("HTML", 5);
		language1.put("Ghekinz", 7);
		language1.put("C and C++", 11);

		@SuppressWarnings("unchecked")
		HashMap<String, Integer> languageClone = (HashMap<String, Integer>) language1.clone();
		System.out.println("HashMap Clone : " + languageClone);

		// Print the Return Value of clone()
		HashMap<String, Integer> primeNumbers1 = new HashMap<>();
		primeNumbers1.put("Two", 2);
		primeNumbers1.put("Three", 3);
		primeNumbers1.put("Five", 5);
		System.out.println("Numbers: " + primeNumbers1);

		System.out.println("Return value of clone(): " + primeNumbers1.clone());

		// isEmpty() Return Value - returns true if the hashmap does not contain any
		// key/value mappings -- returns false if the hashmap contains key/value
		// mappings
		// HashMap<String,Integer> language2 = new HashMap<String,Integer>();
		HashMap<String, Integer> language2 = new HashMap<>();
		System.out.println("Newly Created HashMap: " + language2);

		boolean result1 = language2.isEmpty();
		System.out.println("Is the HashMap empty? " + result1);
		language2 = (HashMap<String, Integer>) language1.clone(); // Language1 clone

		language2.put("Ruby", 9);
		System.out.println("Updated HashMap: " + language2);

		result1 = language2.isEmpty(); // false
		System.out.println("Is the HashMap empty? " + result1);

		// The size() method does not take any parameters. - returns the number of
		// key/value mappings present in the hashmap
		HashMap<String, String> countries = new HashMap<>();
		countries.put("USA", "Washington");
		countries.put("UK", "London");
		countries.put("Canada", "Ottawa");
		System.out.println("HashMap: " + countries);

		countries.put("India", "Mumbai");
		countries.put("UAE", "Dubai");

		int countriesSize = countries.size();
		System.out.println("Map Size:" + countriesSize + " - " + "HashMap: " + countries);

		/*
		 * Put() - key - the specified value is mapped with this key - if key is not
		 * associated with any value, returns null value - the specified key is mapped
		 * with this
		 */
		countries.put("Germany", "Bonn");
		countries.put("Italy", "Milan");
		System.out.println("Countries: " + countries);

		countries.put("Germany", "Berlin ");
		countries.put("Italy", "Rome");
		countries.put("India", "Delhi");
		System.out.println("Update Capitals Countries: " + countries);

		// putAll()

		HashMap<Integer, String> hm1 = new HashMap<>();
		hm1.put(1, "AA");
		hm1.put(2, "AB");
		hm1.put(3, "AC");

		HashMap<Integer, String> hm2 = new HashMap<>();
		hm2.put(11, "BB");
		hm2.put(12, "BB");
		hm2.put(13, "BB");

		System.out.println("First Map-" + hm1 + "\t" + "\n" + "Second Map-" + hm2);

		HashMap<Integer, String> hm3 = new HashMap<>();
		hm3.putAll(hm1); // hm1.putAll(hm2) or hm2.putAll(hm1)
		hm3.putAll(hm2);
		System.out.println("Map3-" + hm3);

		// Insert Mappings from TreeMap to HashMap
		TreeMap<String, String> treemap1 = new TreeMap<>();

		treemap1.put("A", "Apple");
		treemap1.put("B", "Bing");
		treemap1.put("C", "Chrome");
		treemap1.put("D", "Dropbox");
		treemap1.put("E", "EV");
		System.out.println("TreeMap: " + treemap1);

		HashMap<String, String> hashmap1 = new HashMap<>();
		hashmap1.put("V", "Vimeo");
		hashmap1.put("W", "WhatsApp");
		hashmap1.put("X", "XBox");
		hashmap1.put("Y", "YouTube");
		hashmap1.put("Z", "Zoom");
		System.out.println("Initial HashMap: " + hashmap1);

		hashmap1.putAll(treemap1);
		System.out.println("Updated HashMap: " + hashmap1);

		/*
		 * The putIfAbsent() method takes two parameters. key - the specified value is
		 * associated with this key value - the specified key is mapped with this value
		 * returns the value associated with the key, if the specified key is already
		 * present in the hashmap returns null, if the specified key is already not
		 * present in the hashmap
		 */
		HashMap<String, Integer> language3 = new HashMap<>();
		System.out.println("Newly Created HashMap: " + language3);
		language3 = (HashMap<String, Integer>) language2.clone(); // Language1 clone

		System.out.println("New HashMap Language3 -:" + language3);
		language3.putIfAbsent("JavaScript", 00);
		language3.putIfAbsent("React", 10);

		System.out.println("Updated HashMap Language3 -:" + language3);

		/*
		 * The remove() method takes two parameters. key - remove the mapping specified
		 * by this key value (optional) - removes the mapping only if the specified key
		 * maps to the specified value The remove() method removes the mapping and
		 * returns: the previous value associated with the specified key true if the
		 * mapping is removed remove() with Key and Value
		 */
		countries.put("Brazil", "lala");
		language3.put("Perl", 90);
		System.out.println("New Hashmap- " + countries + "\n" + language3);

		countries.remove("Brazil", "lala");
		language3.remove("Perl");
		System.out.println("Remove Element Hashmap- " + countries + "\n" + language3);

		/*
		 * The containsKey() method takes a single parameter. key - mapping for the key
		 * is checked in the hashmap returns true if the mapping for the specified key
		 * is present in the hashmap returns false if the mapping for the specified key
		 * is not present in the hashmap
		 */// need to check the condition both
		boolean result2, result3;
		if (result2 = countries.containsKey("C and")) {
			System.out.println("Domain name is present in the Hashmap." + ":" + result2);
		}
		System.out.println("--");

		if (result3 = countries.containsKey("India")) {
			System.out.println("Domain name is present in the Hashmap." + ":" + result3);
		}

		if (!countries.containsKey("Spain")) {
			// add entry if key already not present
			countries.put("Spain", "Madrid");
		}
		System.out.println("New Countries Add: " + countries);

		/*
		 * The containsValue() method takes a single parameter. value - value is present
		 * in one or more mappings in the HashMap returns true if the specified value is
		 * present or false if not present
		 * 
		 */
		boolean result4, result5 = false;
		if (result4 = countries.containsValue("Madr")) {
			System.out.println("Madrid is present on the list.-->" + result4);
		} else {
			System.out.println("Value is not present on the list.-->" + result4);
		}

		if (result5 = languageClone.containsValue(14)) {
			System.out.println("Value is present on the list.-->" + result5);
		} else {
			System.out.println("Value is not present on the list.-->" + result5);
		}

		// Add Entry to HashMap if Value is already not present

		/*
		 * replace() Parameters The replace() method can take 3 parameters. key - key
		 * whose mapping is to be replaced oldValue (optional)- value to be replaced in
		 * the mapping newValue - oldValue is replaced with this value
		 */
		System.out.println("--1" + hm1);
		System.out.println("--2" + hm2);
		HashMap<Integer, String> hm4 = new HashMap<>();
		hm4.putAll(hm2);
		hm4.putAll(hm1);
		System.out.println("New HashMap4-" + hm4);

		String value1 = hm4.replace(2, "Java");
		System.out.println("Replaced Value: " + value1);
		System.out.println("Updated HashMap: " + hm4);

		HashMap<String, Integer> language4 = new HashMap<>();
		language4 = (HashMap<String, Integer>) language2.clone();
		Integer value2 = language4.replace("C and C++", 21);

		System.out.println("Replaced Value: " + value2);
		System.out.println("Updated HashMap: " + language4);

		// HashMap replace() with Old Value
		HashMap<String, String> countries1 = new HashMap<>();
		countries1.put("Washington", "America");
		countries1.put("Ottawa", "Canada");
		countries1.put("Canberra", "Australia");
		System.out.println("Countries:\n" + countries1);

		countries1.replace("Washington", "America", "USA"); // return true
		countries1.replace("Canberra", "New Zealand", "Victoria"); // return false
		System.out.println("Countries after replace():\n" + countries1);

		/*
		 * HashMap put() Vs. replace() when the hashmap contains the mapping for the
		 * specified key, then both the methods replace the value associated with the
		 * specified key. However, if the hashmap does not contain any mapping for the
		 * specified key, thenthe put() method inserts the new mapping for the specified
		 * key and value the replace() method returns null
		 */

		// The replaceAll() method takes a single parameter. function - operations to be
		// applied to each entry of the hashmap
		HashMap<Integer, Integer> numbers = new HashMap<>();
		numbers.put(5, 0);
		numbers.put(8, 1);
		numbers.put(9, 2);
		System.out.println("HashMap: " + numbers);

		// replace all value with the square of key
		numbers.replaceAll((key, value4) -> key * key);
		System.out.println("Updated HashMap: " + numbers);

		HashMap<String, String> countries2 = new HashMap<>();
		countries2 = (HashMap<String, String>) countries1.clone();

		countries2.replaceAll((key, value5) -> value5.toUpperCase());
		countries2.replaceAll((key, value5) -> value5.toLowerCase());
		System.out.println("Updated HashMap: " + countries2);

		// get() Parametere - The get() method takes a single parameter. key - key whose
		// mapped value is to be returned
		// Note: The method returns null, if either the specified key is mapped to a
		// null value or the key is not present on the hashmap.
		HashMap<Integer, String> hm5 = new HashMap<>();
		hm5 = (HashMap<Integer, String>) hm4.clone();

		HashMap<String, Integer> language5 = new HashMap<>();
		language5 = (HashMap<String, Integer>) language4.clone();

		System.out.println("->" + hm4 + " ## " + "-->" + language5);

		String value3 = hm4.get(3);
		Integer value4 = language5.get("JavaScript");

		System.out.println("->" + value3 + " ## " + "-->" + value4);

		/**
		 * getOrDefault() Parameters The getDefault() method takes two parameters. key -
		 * key whose mapped value is to be returned defaultValue - value which is
		 * returned if the mapping for the specified key is not found - returns thevalue
		 * to which the specified key is associated returns the specified defaultValue
		 * if the mapping for specified key is not found
		 */

		String value5 = hm4.getOrDefault(13, "Not Present");
		Integer value6 = language5.getOrDefault("C# and ASP.net", null);
		System.out.println("->" + value5 + " ?? " + "-->" + value6);

		/**
		 * The forEach() method takes a single parameter. action - actions to be
		 * performed on each mapping of the HashMap
		 * 
		 */
		HashMap<String, Integer> prices = new HashMap<>();
		prices.put("Shoes", 200);
		prices.put("Bag", 300);
		prices.put("Pant", 150);
		System.out.println("Normal Price: " + prices);

		System.out.print("Discounted Price: ");
		// pass lambda expression to forEach()
		prices.forEach((key, value7) -> {

			// decrease value by 10%
			value7 = value7 - value7 * 10 / 100;
			System.out.println(key + "=" + value7 + " ");
		});

		// The entrySet() method does not take any parameter. returns a set view of all
		// the entries of a hashmap

		// return set view of mappings
		Set<Entry<String, Integer>> setview = prices.entrySet();
		// System.out.println("Set View: " + prices.entrySet());

		System.out.println("Set View: " + setview);

		System.out.println("-#&-" + numMap1);
		numMap1.put("Fourth", 4);
		numMap1.put("Fifth", 5);

		for (Entry<String, Integer> entry : numMap1.entrySet()) {
			System.out.println(entry + ", ");
		}

		/**
		 * The keySet() method does not take any parameter. returns a set view of all
		 * the keys of the hashmap
		 */
		System.out.println("Key Set View: " + prices.keySet());
		System.out.println("Key Set View: " + numMap1.keySet());

		// using for each loop
		for (String key1 : numMap1.keySet()) {
			System.out.print(key1 + ", ");
		}

		for (String key2 : language2.keySet()) {
			System.out.print(key2 + ", ");
		}

		/**
		 * The values() method does not take any parameter. returns a collection view of
		 * all values of the hashmap
		 */
		System.out.println("values View map: " + prices.values());
		System.out.println("values View map: " + numMap1.values());

		// using for each loop
		for (int val1 : numMap1.values()) {
			System.out.print(val1 + ", ");
		}

		for (int val2 : language2.values()) {
			System.out.print(val2 + ", ");
		}
		
		/**
		 * */
		System.out.println("<------------------------>");
		// HashMap<KeyType, ValueType> mapName = new HashMap<>();

		System.out.println("HashMap Language Clone : " + languageClone); // String, Integer
		System.out.println("New Language HashMap: " + language2); // // String, Integer
		System.out.println("New Countries HashMap: " + countries); // String, String
		System.out.println("Mergerd HashMap3-" + hm3); // Integer, String
		System.out.println("TreeMap to HashMap: " + hashmap1);

		System.out.println("<-------------------<-$#^->------------------->");
		/*
		 * You have two HashMaps: Map A: HashMap<String, Integer> Map B:
		 * HashMap<Integer, String> These two maps have incompatible types — the key and
		 * value types are reversed. So, you cannot directly clone A into B using
		 * .clone() or assignment, because Java is strongly typed and will throw a type
		 * mismatch error
		 */
		HashMap<String, Integer> mapA = new HashMap<>();
		mapA.put("One", 1);
		mapA.put("Two", 2);
		mapA.put("Three", 3);

		HashMap<Integer, String> mapB = new HashMap<>();

		for (Map.Entry<String, Integer> entry : mapA.entrySet()) {
			mapB.put(entry.getValue(), entry.getKey());
		}

		System.out.println("Map A: " + mapA);
		System.out.println("Map B (reversed): " + mapB);

		/**
		 * ?
		 */
		// MemoryManager.cleanUp();
	}
}
