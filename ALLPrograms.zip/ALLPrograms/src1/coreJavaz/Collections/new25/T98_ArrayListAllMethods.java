package coreJavaz.Collections.new25;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;

public class T98_ArrayListAllMethods {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();

        // add() and addAll()
        list.add(10);
        list.add(20);
        list.add(30);
        ArrayList<Integer> extraList = new ArrayList<>();
        extraList.add(40);
        extraList.add(50);
        list.addAll(extraList);

        // clear() and clone()
        ArrayList<Integer> clonedList = (ArrayList<Integer>) list.clone();
        list.clear();

        // contains()
        boolean contains30 = clonedList.contains(30);

        // ensureCapacity()
        clonedList.ensureCapacity(15);

        // forEach()
        clonedList.forEach(System.out::println);

        // get(), indexOf(), lastIndexOf(), isEmpty(), iterator(), listIterator()
        System.out.println("First Element: " + clonedList.get(0));
        System.out.println("Index of 30: " + clonedList.indexOf(30));
        System.out.println("Last Index of 30: " + clonedList.lastIndexOf(30));
        System.out.println("Is empty: " + clonedList.isEmpty());

        Iterator<Integer> iterator = clonedList.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }

        System.out.println();

        // remove(), removeAll(), removeIf()
        clonedList.remove(Integer.valueOf(30));
        clonedList.removeAll(extraList);
        clonedList.removeIf(num -> num > 20);

        // replaceAll()
        clonedList.replaceAll(num -> num * 2);

        // retainAll()
        clonedList.retainAll(List.of(20, 40));

        // set(), size(), sort(), spliterator()
        clonedList.set(0, 100);
        System.out.println("Size: " + clonedList.size());
        Collections.sort(clonedList);
        Spliterator<Integer> spliterator = clonedList.spliterator();
        spliterator.forEachRemaining(System.out::println);

        // subList(), toArray(), trimToSize()
        List<Integer> subList = clonedList.subList(0, clonedList.size());
        Integer[] array = clonedList.toArray(new Integer[0]);
        clonedList.trimToSize();

        // Display final list
        System.out.println("Final List: " + clonedList);
        
        //
        MemoryManager.cleanUp();
    }
}
