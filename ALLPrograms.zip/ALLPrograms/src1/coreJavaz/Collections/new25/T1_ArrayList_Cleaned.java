/*  Refere this Site for more info - https://www.programiz.com/java-programming/library/arraylist
 * from this site i have done all 
 * 
 * https://beginnersbook.com/java-collections-tutorials/
 * 
*/
package coreJavaz.Collections.new25;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class T1_ArrayList_Cleaned {

	public static void main(String[] args) {

		ArrayList<String> arrListstr1 = new ArrayList<>();
		ArrayList<Integer> arrListint1 = new ArrayList<>();

		arrListstr1.add("Cricket");	arrListstr1.add("Hockey"); arrListstr1.add("BaseBall");	arrListstr1.add("Kabbadi");	arrListstr1.add("Table Tenis");	arrListstr1.add(3, "Archary");
		for (String str1 : arrListstr1) {
			System.out.println(str1 + " \t");
		}

		arrListint1.add(99); arrListint1.add(199); arrListint1.add(399); arrListint1.add(499);  arrListint1.add(699); arrListint1.add(2, 299);
		for (Integer int1 : arrListint1) {
			System.out.println(int1 + " \t");
		}

		ArrayList<String> language = new ArrayList<>();
		language.add("C"); language.add("Ruby"); language.add("Python"); language.add("Java-11");
		System.out.println("-!" + language);

		ArrayList<String> programminglanguage = new ArrayList<String>();
		programminglanguage.addAll(language);
		Collections.sort(programminglanguage);
		System.out.println("-!" + programminglanguage);

		// create an arraylist
		ArrayList<Integer> primeNumbers = new ArrayList<>();
		// add elements to arraylist
		primeNumbers.add(3);
		primeNumbers.add(5);
		System.out.println("Prime Numbers: " + primeNumbers);

		// create another arraylist
		ArrayList<Integer> numbers = new ArrayList<>();
		numbers.add(1);
		numbers.add(2);

		// Add all elements from primeNumbers to numbers
		numbers.addAll(primeNumbers);
		System.out.println("Numbers: " + numbers);

		primeNumbers.addAll(numbers);
		System.out.println("Numbers2: " + primeNumbers);

		// create another arraylist
		ArrayList<String> languages2 = new ArrayList<>();
		languages2.add("JavaScript");
		languages2.add("C# and ASP.net");

		language.addAll(2, languages2);
		System.out.println("--! " + language);

		// - at line 141 check arraylist menthod Contains()

		// Inserting Elements from Set to ArrayList
		// create a hashset of String type
		HashSet<String> set1 = new HashSet<>();

		// add elements to the hashset
		set1.add("Java");
		set1.add("Python");
		set1.add("JavaScript");
		set1.add("Ruby");
		set1.add("Kotlin");
		System.out.println("HashSet: " + set1);

		// Add element to ArrayList
		ArrayList<String> arrList1 = new ArrayList<>();
		arrList1.add("PHP");
		arrList1.add("HTML5");
		arrList1.add("CSS");
		System.out.println("--List:" + arrList1);

		arrList1.addAll(2, set1);
		System.out.println("List after adding set element: " + arrList1);
		Collections.sort(arrList1);
		System.out.println("List after Sort: " + arrList1);

		// remove all elements using clear() and removeAll()
		ArrayList<String> arrList2 = new ArrayList<>();
		arrList2.add("PHP");
		arrList2.add("HTML5");
		arrList2.add("CSS");
		arrList2.add("Javascript");
		System.out.println("--List:" + arrList2);
		arrList2.clear();
		System.out.println("--Cleared List:" + arrList2);

		ArrayList<Integer> oddNumbers = new ArrayList<>();
		oddNumbers.add(1);
		oddNumbers.add(3);
		oddNumbers.add(5);
		oddNumbers.add(7);
		oddNumbers.add(9);
		System.out.println("Odd Number ArrayList: " + oddNumbers);

		Collections.shuffle(oddNumbers);
		oddNumbers.remove(3);
		System.out.println("Odd Single Number Remove: " + oddNumbers);

		oddNumbers.removeAll(oddNumbers);
		System.out.println("All Odd Numbers Remove: " + oddNumbers);

		// Clone the Arraylist
		ArrayList<Integer> number1 = new ArrayList<>();
		number1.add(121);
		number1.add(131);
		number1.add(111);
		number1.add(141);
		number1.add(101);
		System.out.println("Number1 ArrayList: " + number1);

		ArrayList<Integer> number2 = (ArrayList<Integer>) number1.clone();
		System.out.println("Cloned Number1 ArrayList: " + number2);
		Collections.sort(number2);
		System.out.println("Cloned Number1 ArrayList: " + number2);
		// - at line 147 arraylist method contain()

		// String
		System.out.println("--#! " + language);
		boolean ststusStr = language.contains("Ruby");
		System.out.println(ststusStr);
		System.out.println(language.contains("C++"));
		// Int
		System.out.println("--#! " + number1);
		boolean ststusInt = number1.contains(101);
		System.out.println(ststusInt);
		System.out.println(number1.contains(151));

		// arraylist get()
		String str5 = arrListstr1.get(5);
		// String str6 = arrListstr1.get(6); will get error
		System.out.println(str5);
		// System.out.println(str6);

		// indexOf()
		int indxStr = arrListstr1.indexOf(str5);
		System.out.println("-:" + indxStr);

		programminglanguage.add(4, "Java-11");
		// System.out.println("--#!" + programminglanguage);
		int indxstr1 = programminglanguage.indexOf("Java-11");
		System.out.println("-:" + indxstr1);

		// removeAll()
		ArrayList<String> programminglanguage1 = new ArrayList<String>();
		programminglanguage1.addAll(programminglanguage);
		programminglanguage1.add(str5);
		programminglanguage1.add(5, "Golang");
		System.out.println("--1!" + programminglanguage1);

		programminglanguage1.remove(6);
		System.out.println("--2!" + programminglanguage1);

		programminglanguage1.removeAll(programminglanguage1);
		System.out.println("--3!" + programminglanguage1);

		ArrayList<String> languages3 = new ArrayList<>();
		// insert element at the end of arraylist
		languages3.add("Java");
		languages3.add("English");
		languages3.add("C");
		languages3.add("C++");
		languages3.add("Spanish");
		languages3.add("Marathi");
		System.out.println("Languages3: " + languages3);

		// create another arraylist
		ArrayList<String> languages4 = new ArrayList<>();

		// add elements to the arraylist
		languages4.add("English");
		languages4.add("Spanish");
		languages4.add("Marathi");
		System.out.println("Languages4: " + languages4);

		Collections.shuffle(languages3);
		languages3.removeAll(languages4);
		System.out.println("Languages3 after removeAll(): " + languages3);

		// Remove all Elements from an ArrayList Present in a HashSet
		ArrayList<Integer> number = new ArrayList<Integer>();
		number.add(1);
		number.add(2);
		number.add(3);
		number.add(4);
		number.add(5);
		number.add(7);
		System.out.println("ArrayList: " + number);

		HashSet<Integer> primenum = new HashSet<Integer>();
		primenum.add(2);
		primenum.add(3);
		primenum.add(5);
		primenum.add(7);
		System.out.println("HashSet: " + primenum);

		number.removeAll(primenum);
		System.out.println("ArrayList after removeAll(): " + number);

		number.retainAll(primenum);
		System.out.println("ArrayList after retainAll(): " + number);

		// remove()
		// 1. create an ArrayList
		ArrayList<String> languages5 = new ArrayList<>();
		languages5.add("JavaScript");
		languages5.add("Java");
		languages5.add("Python");
		System.out.println("ArrayList: " + languages5);
		boolean result11 = languages5.remove("Java");
		System.out.println("Is element Java removed? " + result11);
		System.out.println("ArrayList after remove(): " + languages5);

		// 2 create an ArrayList
		ArrayList<String> languages6 = new ArrayList<>();
		languages6.add("JavaScript");
		languages6.add("Java");
		languages6.add("Python");
		System.out.println("ArrayList: " + languages6);
		// remove the element from position 2
		String element1 = languages6.remove(2);
		System.out.println("ArrayList after remove(): " + languages6);
		System.out.println("Removed Element: " + element1);

		// 3. create an ArrayList
		ArrayList<Integer> randomNumbers1 = new ArrayList<>();
		randomNumbers1.add(22);
		randomNumbers1.add(13);
		randomNumbers1.add(35);
		randomNumbers1.add(13);
		randomNumbers1.add(40);
		System.out.println("ArrayList: " + randomNumbers1);
		// remove the first occurrence of 13
		boolean result12 = randomNumbers1.remove(Integer.valueOf(13));
		System.out.println("Is element 13 removed? " + result12);
		System.out.println("ArrayList after remove(): " + randomNumbers1);

		// get the number of elements of arraylist size()
		int size = randomNumbers1.size();
		System.out.println("Length of ArrayList: " + size);

		// get the length of arraylist
		int size1 = languages3.size();
		System.out.println("Length of ArrayList: " + size1);

		// isEmpty()
		boolean result13 = arrList2.isEmpty(); // true
		System.out.println("Is the ArrayList empty? " + result13);

		boolean result14 = languages3.isEmpty(); // false
		System.out.println("Is the ArrayList empty? " + result14);

		// SubList() element from 1 to 3
		System.out.println("SubList: " + programminglanguage);
		System.out.println("SubList: " + programminglanguage.subList(1, 4));

		// 1. create an ArrayList
		ArrayList<Integer> ages = new ArrayList<>();
		ages.add(10);
		ages.add(12);
		ages.add(15);
		ages.add(19);
		ages.add(23);
		ages.add(34);
		System.out.println("List of Age: " + ages);

		// ages below 18
		System.out.println("Ages below 18: " + ages.subList(0, 3));
		// ages above 18
		System.out.println("Ages above 18: " + ages.subList(3, ages.size()));

		// Set()
		arrListstr1.add("lala");
		arrListint1.add(799);

		int a1 = arrListstr1.size();
		int a2 = arrListint1.size();

		System.out.println(":" + a1 + "-" + a2);

		String element = arrListstr1.set(6, "Volly Ball");
		int element11 = arrListint1.set(5, 559);
		int element12 = arrListint1.set(6, 699);

		// create an ArrayList
		ArrayList<String> languages7 = new ArrayList<>();
		languages7.add("Python");
		languages7.add("English");
		languages7.add("JavaScript");
		ArrayList<String> languages8 = new ArrayList<>();
		languages8.addAll(languages7);
		System.out.println("ArrayList: " + languages7);

		// use of set() replace
		languages7.set(1, "Java");
		System.out.println("ArrayList after set(): " + languages7);

		// use of add() add new
		languages8.add(2, "Java");
		System.out.println("ArrayList after add(): " + languages8);

		// sort
		arrList1.sort(Comparator.naturalOrder());

		number1.sort(Comparator.reverseOrder());
		System.out.println("" + number1);

		// ArrayList to Array()
		ArrayList<String> languages9 = new ArrayList<>();
		languages9.addAll(programminglanguage);
		System.out.println("ArrayList: " + languages9);

		String[] arr11 = new String[languages9.size()];
		languages9.toArray(arr11);

		System.out.print("Array(languages9): ");
		for (String str1 : arr11) {
			System.out.print(str1 + " ");
		}

		// ArrayList toArray() Method without Parameter
		ArrayList<String> languages10 = new ArrayList<>();
		languages10.addAll(programminglanguage);

		Object[] obj1 = languages10.toArray();
		// print all elements of the array
		System.out.print("Array(languages10): ");
		for (Object item : obj1) {
			System.out.print(item + ", ");
		}
		System.out.println(" ");

		// ArrayList() to String
		ArrayList<String> programminglanguage2 = new ArrayList<>();
		programminglanguage2.addAll(programminglanguage);
		programminglanguage2.add("TypeScript");
		System.out.println("--! " + programminglanguage2);
		Collections.shuffle(programminglanguage2);
		
		String list1 = programminglanguage2.toString();
		System.out.println("String -:"+ list1);
		
		// ensureCapacity() Parameters
		ArrayList<String> programminglanguage3 = new ArrayList<>();
		programminglanguage3.ensureCapacity(3);
		programminglanguage3.add("E1"); programminglanguage3.add("E2"); programminglanguage3.add("E#"); programminglanguage3.add("E$"); 
		
		System.out.println("--! " +programminglanguage3);
		
		//lastIndexOf()
		ArrayList<String> programminglanguage4 = new ArrayList<>();
		programminglanguage4.addAll(programminglanguage3);
		System.out.println("--! " +programminglanguage4);
		
		int position = programminglanguage4.lastIndexOf("E#");
		System.out.println("-"+position);
		
		programminglanguage4.add("E2"); programminglanguage4.add("E#");
		position = programminglanguage4.lastIndexOf("E#");
		System.out.println("-"+position);
		
		// 
		ArrayList<String> programminglanguage5 = new ArrayList<>();
		programminglanguage5.addAll(programminglanguage3);
		programminglanguage5.add("E&"); programminglanguage5.add("E!");
		System.out.println("--! " +programminglanguage5);
		
		
		programminglanguage5.retainAll(programminglanguage3);
		System.out.println("Common Elements --! " +programminglanguage5);
		
		// Show Common Elements Between ArrayList and HashSet we can do this as well
		//containsAll()
		System.out.println(programminglanguage3);
		System.out.println(programminglanguage4);
		programminglanguage4.add("E&"); programminglanguage4.add("E*");
		System.out.println(programminglanguage4 + "--" + programminglanguage4.size());
		
		boolean result15 = programminglanguage4.containsAll(programminglanguage3);
		System.out.println(result15);
		
		boolean result16 = programminglanguage3.containsAll(programminglanguage4);
		System.out.println(result16);
		
		// containsAll() Between Java ArrayList and HashSet
		
		// The trimToSize() method does not take any parameters
		programminglanguage4.trimToSize();
		ages.trimToSize();
		System.out.println(programminglanguage4);
		System.out.println(ages);
		System.out.println(ages.size() + "--"+programminglanguage4.size());
		
		//The removeRange() method does not return any values. Rather, it removes a portion of arraylist.
		ArrayList<String> programminglanguage6 = new ArrayList<>();
		programminglanguage6.addAll(programminglanguage4);
		programminglanguage6.add("E%");
		
		System.out.println(programminglanguage6);
		programminglanguage6.remove(4);
		System.out.println(programminglanguage6);
		
		programminglanguage6.subList(3, 6).clear();
		System.out.println(programminglanguage6);
		
		// The replaceAll() method takes a single parameter.
		//programminglanguage2.replaceAll(e -> e.toUpperCase());
		//programminglanguage2.replaceAll(e -> e.toLowerCase());
		programminglanguage2.replaceAll(a -> a.repeat(2));
		System.out.println(programminglanguage2);
		
		//The removeIf() method takes a single parameter.
		
		//The forEach() method performs the specified action on each element of the arraylist one by one.
		
		// The iterator() method does not take any parameters.

		System.out.println("#-------------&$@----------------#");
		
		System.out.println("HashSet: " + set1);
		System.out.println("HashSet: " + primenum);
		
		System.out.println(programminglanguage);
		System.out.println(programminglanguage1);
		System.out.println(programminglanguage2);
		System.out.println(programminglanguage3);
		System.out.println(programminglanguage4);
		System.out.println(programminglanguage5);

		ArrayList<String> testingFrameworks = new ArrayList<>();
		testingFrameworks.add("JUnit");
		testingFrameworks.add("TestNG");
		testingFrameworks.add("Mockito");
		testingFrameworks.add("Cucumber");
		testingFrameworks.add("Rest Assured");
		testingFrameworks.add("Selenium");
		testingFrameworks.add("PyTest");
		testingFrameworks.add("Jest");
		testingFrameworks.add("Mocha");
		testingFrameworks.add("NUnit");
		System.out.println("Major Testing Frameworks:");
		for (String framework : testingFrameworks) {
			System.out.print("-" + framework + ",");
		}

		ArrayList<Integer> uniqueIntegers = new ArrayList<>();
		uniqueIntegers.add(0); // Additive identity
		uniqueIntegers.add(1); // Multiplicative identity
		uniqueIntegers.add(2); // From √2
		uniqueIntegers.add(3); // Approximation of π
		uniqueIntegers.add(7); // Often used in modular arithmetic
		uniqueIntegers.add(10); // Base of decimal system
		uniqueIntegers.add(42); // "Answer to the Ultimate Question" (fun reference)
		uniqueIntegers.add(137); // Fine-structure constant (approx.)
		uniqueIntegers.add(1729); // Hardy-Ramanujan number

		// Print the list
		System.out.println("Unique Mathematical Integers:");
		for (Integer num : uniqueIntegers) {
			System.out.print("-" + num + ",");
		}

		System.out.println("--#!");
		
		System.out.println("--#!"+ testingFrameworks);
		System.out.println("--#!"+ uniqueIntegers);
		System.out.println("--#!" + arrListstr1);
		System.out.println("--#!" + arrListint1);
		System.out.println("--#!" + programminglanguage);
		System.out.println("--#!" + language);
		System.out.println("--#!" + primeNumbers);
		System.out.println("--#!" + numbers);
		System.out.println("--#!" + arrList1);
		System.out.println("--#!" + arrList2);
		System.out.println("--#!" + oddNumbers);
		System.out.println("--#!" + number1);
		System.out.println("--#!" + randomNumbers1);
		System.out.println("--#!" + ages);

		System.out.println("#-------------&----------------#");
		// Some Random Methods

		String str1 = "Java String contains()";
		// check if str1 contains "Java"
		boolean result = str1.contains("Java");
		System.out.println(result);

		// check if str1 contains "Python"
		result = str1.contains("Python");
		System.out.println(result);

		// check if str1 contains ""
		result = str1.contains("");
		System.out.println(result);

		String str2 = "Learn Java";
		String str3 = "Java";
		String str4 = "java";
		Boolean result1;

		// true because "Learn Java" contains "Java"
		if (str2.contains(str3)) {
			System.out.println(str2 + " contains " + str3);
		} else {
			System.out.println(str2 + " doesn't contains " + str3);
		}

		// contains() is case-sensitive
		// false because "Learn Java" doesn't contains "java"
		if (str2.contains(str4)) {
			System.out.println(str2 + " contains " + str4);
		} else {
			System.out.println(str2 + " doesn't contain " + str4);
		}
		//
		System.out.println("-----------------------------#");
		int[] intArray = { 1, 2, 3, 4, 5 };
		List<Integer> intList1 = new ArrayList<>();
		for (int i = 0; i < intArray.length; i++) {
			intList1.add(intArray[i]);
		}
		System.out.println("--:" + intList1);

		// Char Array
		String[] arr = { "A", "B", "C", "D" };
		convertUsingAddAll(arr);

		// Int Array
		Integer[] arr1 = { 1, 2, 3, 4, 5 };
		convertUsingAsList(arr1);

		// String Array
		String[] arr2 = { "Java", "Python", "C++" };
		convertUsingStream(arr2);

		String[] arr3 = { "Geek1", "Geek2", "Geek3" };
		convertUsingListOf(arr3);

		// 2D array
		int[][] twoDArray = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		List<List<Integer>> arrayList2D = convert2DArrayToArrayList(twoDArray);
		System.out.println(arrayList2D);

		// Call memory cleanup
		//MemoryCleaner.clearMemory();
		//MemoryManager.cleanUp();
	}

	public static void convertUsingAddAll(String[] arr) {
		ArrayList<String> al = new ArrayList<>();
		Collections.addAll(al, arr);
		System.out.println(al);
	}

	public static void convertUsingAsList(Integer[] arr) {
		ArrayList<Integer> al = new ArrayList<>(Arrays.asList(arr));
		System.out.println(al);
	}

	public static void convertUsingStream(String[] arr) {
		ArrayList<String> al = (ArrayList<String>) Arrays.stream(arr).collect(Collectors.toList());
		System.out.println(al);
	}

	public static void convertUsingListOf(String[] arr) {
		ArrayList<String> al = new ArrayList<>(List.of(arr));
		System.out.println(al);
	}

	public static List<List<Integer>> convert2DArrayToArrayList(int[][] array) {
		return Arrays.stream(array).map(row -> Arrays.stream(row).boxed().collect(Collectors.toList()))
				.collect(Collectors.toList());
	}
}
