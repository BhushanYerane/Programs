package coreJavaz.Collections.new25;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class T99_assignment {
	
	public static void main(String[] args) {
		
		int array1[] = {3,1,11,19,17};
		int array2[] = {5,2,6,7,20};
		String[] array4 = {"Apple", "Banana", "Cherry"};
		String array3[] = {"Kiwi", "DraganFruit", "BlueBerry","Pears"};
		
		ArrayList<Integer> inputA = new ArrayList<Integer>();
		
		//add you integer array in one arraylist
		for(int num: array1)
		{
			inputA.add(num);
		}
		for(int num: array2)
		{
			inputA.add(num);
		}
		
		System.out.println("--# :"+inputA);
		// Sort Array Integer
		Collections.sort(inputA);
		System.out.println("Sorted --# :"+inputA);
		int arraylistSize = inputA.size();
		
		int num1 = inputA.get(2);
		System.out.println("--"+num1);
		
		//add you string array in one arraylist
		ArrayList<String> inputB = new ArrayList<>(Arrays.asList(array3));
		inputB.addAll(Arrays.asList(array4));
		System.out.println("--: "+inputB);
		
		// Sort Array String
		Collections.sort(inputB);
		System.out.println("Sorted --: "+inputB);
		
		String str1 = inputB.get(5);
		System.out.println("--"+str1);
	}

}
