package coreJavaz.Collections.new25;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class MemoryCleaner {

	public static void clearMemory() {
	    try {
	        // Measure memory before GC
	        long beforeUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();

	        // Suggest garbage collection
	        System.gc();
	        Runtime.getRuntime().gc();

	        // Optional: Pause to allow GC to complete
	        Thread.sleep(100);

	        // Measure memory after GC
	        long afterUsedMem = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
	        long memoryFreed = beforeUsedMem - afterUsedMem;

	        System.out.println("<0--------------------------0>");
	        System.out.println("Garbage collection triggered.");
	        System.out.println("Memory used before GC: " + beforeUsedMem / 1024 + " KB");
	        System.out.println("Memory used after GC: " + afterUsedMem / 1024 + " KB");
	        System.out.println("Approx. memory freed: " + memoryFreed / 1024 + " KB");

	    } catch (InterruptedException e) {
	        System.err.println("Memory cleanup interrupted: " + e.getMessage());
	    }
	}
}
