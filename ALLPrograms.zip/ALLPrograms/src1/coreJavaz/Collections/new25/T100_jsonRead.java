package coreJavaz.Collections.new25;

import java.util.*;

public class T100_jsonRead {

    public static void main(String[] args) {
        Map<String, List<String>> brands = getBrands();
        List<Map<String, Object>> subsidiaries = getSubsidiaries();
        Map<String, Object> sustainability = getSustainability();

        printBrands(brands);
        printSubsidiaries(subsidiaries);
        printSustainability(sustainability);
    }

    public static Map<String, List<String>> getBrands() {
        return Map.of(
            "cars", List.of("Volkswagen Passenger Cars", "Audi", "Porsche", "SEAT", "Škoda", "Lamborghini", "Bentley", "Bugatti"),
            "trucks", List.of("MAN", "Scania", "Volkswagen Caminhões e Ônibus"),
            "buses", List.of("Volkswagen Bus", "MAN Bus", "Scania Bus")
        );
    }

    public static List<Map<String, Object>> getSubsidiaries() {
        return List.of(
            Map.of(
                "name", "Volkswagen Financial Services",
                "type", "Finance",
                "services", List.of("Leasing", "Banking", "Insurance", "Fleet Management")
            ),
            Map.of(
                "name", "Volkswagen Group Components",
                "type", "Manufacturing",
                "focus", List.of("Batteries", "Electric Drives", "Charging Infrastructure")
            ),
            Map.of(
                "name", "Cariad",
                "type", "Software",
                "focus", List.of("Automotive Software", "ADAS", "Infotainment")
            )
        );
    }

    public static Map<String, Object> getSustainability() {
        return Map.of(
            "strategy", "Way to Zero",
            "goals", Map.of(
                "carbonNeutralBy", 2050,
                "electricVehiclesShareBy2030", "70%"
            )
        );
    }

    public static void printBrands(Map<String, List<String>> brands) {
        System.out.println("Volkswagen AG Brands:");
        brands.forEach((type, list) -> {
            System.out.println("  " + type.toUpperCase() + ":");
            list.forEach(brand -> System.out.println("    - " + brand));
        });
    }

    public static void printSubsidiaries(List<Map<String, Object>> subsidiaries) {
        System.out.println("\nSubsidiaries:");
        subsidiaries.forEach(sub -> {
            System.out.println("  Name: " + sub.get("name"));
            System.out.println("  Type: " + sub.get("type"));
            String key = sub.containsKey("services") ? "services" : "focus";
            System.out.println("  " + capitalize(key) + ":");
            ((List<?>) sub.get(key)).forEach(item -> System.out.println("    - " + item));
            System.out.println();
        });
    }

    public static void printSustainability(Map<String, Object> sustainability) {
        System.out.println("Sustainability Strategy:");
        System.out.println("  Strategy: " + sustainability.get("strategy"));
        Map<?, ?> goals = (Map<?, ?>) sustainability.get("goals");
        goals.forEach((goal, value) -> System.out.println("  " + goal + ": " + value));
    }

    private static String capitalize(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}

