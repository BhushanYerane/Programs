package coreJavaz.Collections.new25;

import java.util.HashMap;
import java.util.Map;

public class MemoryManager {

	// Simulated cookie storage
	private static final Map<String, String> cookies = new HashMap<>();

	public static void cleanUp() {
		// Simulate memory usage
		String[] data = new String[1000000];
		for (int i = 0; i < data.length; i++) {
			data[i] = "Data " + i;
		}

		// Simulate cookie storage
		cookies.put("session", "abc123");
		cookies.put("user", "john_doe");
		System.out.println("<0-----------Cleane up---------------0>");

		// Measure memory usage before cleanup
		long usedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		System.out.println("Memory used before cleanup: " + usedMemory / 1024 + " KB");

		// Clear cookies
		cookies.clear();

		// Suggest garbage collection
		System.gc();
		Runtime.getRuntime().gc();

		// Measure memory after cleanup
		long afterCleanupMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		System.out.println("Memory used after cleanup: " + afterCleanupMemory / 1024 + " KB");

		// Calculate and print memory cleaned up
		long memoryCleaned = usedMemory - afterCleanupMemory;
		System.out.println("Memory cleaned up: " + memoryCleaned / 1024 + " KB");

		System.out.println("<0--------------------------0>");
		System.out.println("Cookies and memory cleared.");
	}
}
