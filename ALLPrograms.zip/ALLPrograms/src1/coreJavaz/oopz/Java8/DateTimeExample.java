package coreJavaz.oopz.Java8;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class DateTimeExample {
    public static void main(String[] args) {
        LocalDate date = LocalDate.now();
        LocalTime time = LocalTime.now();
        LocalDateTime dateTime = LocalDateTime.now();

        System.out.println("Current Date: " + date);
        System.out.println("Current Time: " + time);
        System.out.println("Current DateTime: " + dateTime);

        // Specific Date and Time
        LocalDate specificDate = LocalDate.of(2020, 1, 1);
        LocalTime specificTime = LocalTime.of(10, 30);
        LocalDateTime specificDateTime = LocalDateTime.of(2020, 1, 1, 10, 30);

        System.out.println("Specific Date: " + specificDate);
        System.out.println("Specific Time: " + specificTime);
        System.out.println("Specific DateTime: " + specificDateTime);
    }
}

