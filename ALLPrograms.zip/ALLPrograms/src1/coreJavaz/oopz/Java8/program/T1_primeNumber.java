package coreJavaz.oopz.Java8.program;

import java.util.Scanner;
import java.util.stream.IntStream;

public class T1_primeNumber {

	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		boolean status = false;
		
		System.out.print("Enter number: ");
		int num = scan.nextInt();
		
		status = isPrimeByJava8(num);
		
		System.out.println("Is Number "+num+" Prime No? -"+ status );
		
		scan.close();
	}

	private static boolean isPrimeByJava8(int n) {
		if (n == 0 || n == 1) {
			return false;
		}
		if (n == 2) {
			return true;
		}
		boolean isPrime = IntStream.rangeClosed(2, n / 2).noneMatch(x -> n % x == 0);
		return isPrime;
	}
}