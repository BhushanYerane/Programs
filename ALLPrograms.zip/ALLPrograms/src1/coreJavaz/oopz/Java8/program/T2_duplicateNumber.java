package coreJavaz.oopz.Java8.program;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class T2_duplicateNumber {

	 public static void main(String[] args) {
	        int[] a = {1, 4, 5, 2, 12, 34, 2, 11, 4, 11};

	        List<Integer> dupNum = findDuplicateNumberByJava8(a);

	        System.out.println("Duplicate numbers by Java 1.8: " + dupNum);
	    }

	    private static List<Integer> findDuplicateNumberByJava8(int[] a) {
	        // Group by the number and count occurrences
	        Map<Integer, Long> frequencyMap = Arrays.stream(a).boxed()
	                							.collect(Collectors.groupingBy(Function.identity(),
	                									 Collectors.counting()));

	        // Filter out numbers that have a count greater than 1
	        List<Integer> duplicate = frequencyMap.entrySet()
	        							.stream().filter(entry -> entry.getValue() > 1)
	        							.map(Map.Entry::getKey)
	        							.collect(Collectors.toList());
	        return duplicate;
	    }
}
