package coreJavaz.oopz.Java8;

import java.util.Optional;

public class OptionalExample {
    public static void main(String[] args) {
        String[] words = new String[10];
        Optional<String> optionalWord = Optional.ofNullable(words[5]);

        if (optionalWord.isPresent()) {
            System.out.println(words[5].toLowerCase());
        } else {
            System.out.println("Word is not present");
        }

        // Using orElse
        String word = optionalWord.orElse("Default");
        System.out.println(word);
    }
}
