package coreJavaz.oopz.Java8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LambdaExample {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("John", "Alice", "Bob", "Charlie");

        // Before Java 8
        Collections.sort(names, (String a, String b) -> a.compareTo(b));
        System.out.println("Sorted names: " + names);
        
        System.out.println("----------");

        // With Lambda Expression
        names.sort((a, b) -> a.compareTo(b));
        System.out.println("Sorted names with Lambda: " + names);
    }
}

