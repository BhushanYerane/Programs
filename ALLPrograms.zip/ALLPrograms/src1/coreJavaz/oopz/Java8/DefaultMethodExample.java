package coreJavaz.oopz.Java8;

interface Vehicle {
    void start();

    // Default Method
    default void clean() {
        System.out.println("Cleaning the vehicle");
    }
}

class Car implements Vehicle {
    @Override
    public void start() {
        System.out.println("Car is starting");
    }
}

public class DefaultMethodExample {
    public static void main(String[] args) {
        Car car = new Car();
        car.start();
        car.clean(); // Calling default method
    }
}

