package coreJavaz.oopz.Java8;

interface MathOperations {
    static int add(int a, int b) {
        return a + b;
    }
    static int multiply(int a, int b) {
        return a * b;
    }
}

public class StaticMethodExample {
    public static void main(String[] args) {
        int result = MathOperations.add(5, 3);
        System.out.println("Addition result: " + result);
        
        int result1= MathOperations.multiply(5, 3);
        System.out.println("Multiplication result: " + result1);
    }
}

