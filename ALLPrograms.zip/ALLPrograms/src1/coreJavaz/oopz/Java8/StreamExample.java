package coreJavaz.oopz.Java8;

import java.util.Arrays;
import java.util.List;

public class StreamExample {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("John", "Alice", "Bob", "Charlie", "John");

        // Filter and Print
        names.stream()
             .filter(name -> name.startsWith("J"))
             .forEach(System.out::println);
        
        System.out.println("----------");

        // Find distinct names
        names.stream()
             .distinct()
             .forEach(System.out::println);
    }
}
