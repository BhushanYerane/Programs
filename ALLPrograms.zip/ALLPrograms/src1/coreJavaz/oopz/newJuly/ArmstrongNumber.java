package coreJavaz.oopz.newJuly;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("Enter the number: ");
		int num = scan.nextInt();

		// Separate the digits
		List<Integer> digits = separateDigits(num);
		System.out.println("Digits: " + digits);

		System.out.println("---------------------------");

		// Check if the number is an Armstrong number
		if (isArmstrong(num, digits)) {
			System.out.println("Number is Armstrong");
		} else {
			System.out.println("Number is not Armstrong");
		}
		
		System.out.println("-------------------------");

		// Using Java8
		System.out.println("Is Armstrong Number : " + isArmstrongNumberByJava8(num));
		scan.close();
	}

	private static boolean isArmstrongNumberByJava8(int n) {
		int len = String.valueOf(n).length();
		int sum = String.valueOf(n).chars().map(ch -> Character.digit(ch, 10)).map(digit -> (int) Math.pow(digit, len))
				.sum();
		return sum == n;
	}

	public static List<Integer> separateDigits(int num) {
		List<Integer> digits = new ArrayList<>();
		int count = 0;

		while (num > 0) {
			int digit = num % 10;
			digits.add(0, digit); // Add digit to the front to maintain order
			num = num / 10;
			count++;
		}
		System.out.println("Number of digits: " + count);
		return digits;
	}

	public static boolean isArmstrong(int num, List<Integer> digits) {
		int digitslen = digits.size();
		double sum = 0;

		for (int digit : digits) {
			sum = sum + Math.pow(digit, digitslen);
		}

		System.out.println("Computed sum: " + sum);
		return sum == num;
	}
}