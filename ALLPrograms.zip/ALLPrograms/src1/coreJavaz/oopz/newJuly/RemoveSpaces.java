package coreJavaz.oopz.newJuly;

public class RemoveSpaces {

	public static void main(String[] args) {

		String str = "This is a test string with spaces";

		// Create a StringBuilder object
		//StringBuilder sb = new StringBuilder();
		StringBuffer sb = new StringBuffer();

		// Iterate through each character in the string
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			// Append only non-space characters to the StringBuilder
			if (c != ' ') {
				sb.append(c);
			}
		}

		// Convert the StringBuilder to a string
		String result = sb.toString();

		System.out.println("Original string: \"" + str + "\"");
		System.out.println("String without spaces: \"" + result + "\"");
		
		System.out.println("---------------------------");
		
		// Create a char array to store the result
        char[] resultArray = new char[str.length()];
        int count = 0;
        
        // Iterate through each character in the string
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            // Add only non-space characters to the result array
            if (c != ' ') {
                resultArray[count] = c;
                count++;
            }
        }
        
        // Convert the result array to a string
        String result1 = new String(resultArray, 0, count);
        
        System.out.println("Original string: \"" + str + "\"");
        System.out.println("String without spaces: \"" + result1 + "\"");
	}
}
