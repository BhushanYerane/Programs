package coreJavaz.oopz.newJuly;

import java.util.Arrays;
import java.util.List;

public class CheckOddNumber {

	public static boolean areAllNumbersOdd(List<Integer> numbers) {
		for (int number : numbers) {
			if (number % 2 == 0) {
				return false; // Found an even number, return false
			}
		}
		return true; // All numbers are odd, return true
	}

	public static void main(String[] args) {
		List<Integer> list1 = Arrays.asList(1, 3, 5, 7, 9);
		List<Integer> list2 = Arrays.asList(1, 2, 3, 4, 5);

		System.out.println("List 1 contains only odd numbers: " + areAllNumbersOdd(list1));
		System.out.println("List 2 contains only odd numbers: " + areAllNumbersOdd(list2));
	}
}
