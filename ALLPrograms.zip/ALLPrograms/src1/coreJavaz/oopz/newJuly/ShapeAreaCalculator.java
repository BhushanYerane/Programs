package coreJavaz.oopz.newJuly;

public class ShapeAreaCalculator {

	public static void main(String[] args) {

		Circle circle = new Circle(5);
		Rectangle rectangle = new Rectangle(4, 6);
		Square square = new Square(3);

		System.out.println("Area of circle: " + circle.getArea());
		System.out.println("Area of rectangle: " + rectangle.getArea());
		System.out.println("Area of square: " + square.getArea());
	}
}
