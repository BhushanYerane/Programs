package coreJavaz.oopz.newJuly;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		// Part 1: Check if a user-entered number is prime
		System.out.print("Enter a number to check if it is prime: ");
		int number = scanner.nextInt();
		if (isPrime(number)) {
			System.out.println(number + " is a prime number.");
		} else {
			System.out.println(number + " is not a prime number.");
		}

		// Part 2: Generate prime numbers up to a user-specified limit
		 System.out.print("Enter a limit to generate prime numbers up to that limit: ");
	     int limit = scanner.nextInt();
	     generatePrimes(limit);
	     
	     int num = 29+29;
	     boolean flag = false;
	     for (int i = 2; i <= num / 2; ++i) {
	       // condition for nonprime number
	       if (num % i == 0) {
	         flag = true;
	         break;
	       }
	     }

	     if (!flag)
	       System.out.println(num + " is a prime number.");
	     else
	       System.out.println(num + " is not a prime number.");
		
		scanner.close();
	}

	// Method to check if a number is prime
	public static boolean isPrime(int number) {
		if (number <= 1) {
			return false; // 1 and below are not prime numbers
		}
		for (int i = 2; i <= Math.sqrt(number); i++) {
			if (number % i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public static void generatePrimes(int limit) {
        System.out.println("Prime numbers up to " + limit + ":");
        if (limit <= 1) {
			return; // 1 and below are not prime numbers
		}
        for (int i = 2; i <= limit; i++) {
            if (isPrime(i)) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

}
