package coreJavaz.oopz.newJuly;

import java.util.Scanner;

public class differentProg 
{

	public static void main(String[] args) 
	{
		 Scanner scn = new Scanner(System.in);
	        int n = scn.nextInt();
	        System.out.println("Dividing this number by 0");
	        try {
	            System.out.println(n/1);
	        } catch(Exception e) {
	            System.out.println(e);
	        }
	        System.out.println("Program completed");
	        
	        scn.close();
	        
	        System.out.println("-----------------------------------");
	        
	        Thread t = Thread.currentThread();
	        t.setName("My Main Thread");
	        t.setPriority(7);
	        System.out.println(t);
	        System.out.println(t.getName());
	        System.out.println(t.getPriority());
	 }
}
