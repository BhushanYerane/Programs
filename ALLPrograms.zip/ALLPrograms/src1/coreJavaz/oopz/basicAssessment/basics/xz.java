package coreJavaz.oopz.basicAssessment.basics;

import java.io.*;
import java.util.*;
import java.util.stream.*;

public class xz {

    /*
     * Complete the 'findNumber' function below.
     *
     * The function is expected to return a STRING.
     * The function accepts following parameters:
     *  1. INTEGER_ARRAY arr
     *  2. INTEGER k
     */

    public static String findNumber(List<Integer> arr, int k) {
        // Check if k is in arr
        for (int a : arr) {
            if (a == k) {
                return "YES";
            }
        }
        return "NO";
    }
}
