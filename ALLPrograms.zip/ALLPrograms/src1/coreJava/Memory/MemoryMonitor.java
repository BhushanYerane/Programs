package coreJava.Memory;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class MemoryMonitor extends Thread {
    private boolean running = true;
    private static final String LOG_DIR = "coreJava/Memory";
    private static final String LOG_FILE = LOG_DIR + "/memory_log.csv";

    @Override
    public void run() {
        try {
            // Ensure the directory exists
            File dir = new File(LOG_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            try (FileWriter writer = new FileWriter(LOG_FILE)) {
                writer.write("Timestamp,UsedMemoryKB\n");

                while (running) {
                    long used = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
                    long timestamp = System.currentTimeMillis();
                    writer.write(timestamp + "," + (used / 1024) + "\n");
                    writer.flush();

                    if (used > 200 * 1024 * 1024) {
                        System.out.println("[Suggestion] High memory usage detected. Consider optimizing object creation or invoking GC.");
                    }

                    Thread.sleep(1000); // Log every second
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void stopMonitoring() {
        running = false;
    }
}

