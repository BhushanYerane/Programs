package coreJava.Memory;

import java.util.Scanner;

public class TestFileInterviews {

	public static void main(String[] args) {
		/*
		 * Scanner scan = new Scanner(System.in); System.out.print("Enter number: ");
		 * int num = scan.nextInt(); boolean isPrime = true;
		 * 
		 * System.out.println(num); if (num <= 1) { isPrime = false;
		 * System.out.println("It is not Prime num"); } for (int i = 2; i <= num / 2;
		 * i++) { if (num % i == 0) { isPrime = false; break; } } if (isPrime) {
		 * System.out.println("It is Prime num"); } else {
		 * System.out.println("It is not Prime num"); }
		 */
	
		/*
		 * System.out.print("print Char: " ); for(char ch='a';ch<='z';ch++) {
		 * System.out.print(ch); }
		 * System.out.println("print Char: " ); for(int i=65;i<=90;i++) {
		 * System.out.print((char)i); }
		 */
		
		/*
		 * int arr1[] = {2468},arr2=0; for(int i=0;i<arr1.length;i++) {
		 * System.out.print(arr1[i]);
		 * } arr2 = arr1[i]+arr2;
		 */
		
		/*
		 * String str1="I am lalalaalallalalalalalal,snb csdlbkv mn askkbdlfknk"; char
		 * ch1[]; ch1 = str1.toCharArray(); for(char c1:ch1) { System.out.print(c1+",");
		 * }
		 * char[] letters = {'H', 'e', 'l', 'l', 'o', ' ', 'J', 'a', 'v', 'a'};
		 * 
		 * String str2 = new String(letters); System.out.println(str2);
		 */
        
		/*
		 * int a=0,b=1,num;
		 * for(int i=2;i<=10;i++) { num = a+b; System.out.println(num); a=b; b=num; }
		 */
	}
}
