package coreJava.Memory;

import java.util.HashMap;
import java.util.Map;

public class MemoryManager {
    private static final Map<String, String> cookies = new HashMap<>();

    public static void cleanUp() {
        // Simulate memory usage
        String[] data = new String[1000000];
        for (int i = 0; i < data.length; i++) {
            data[i] = "Data " + i;
        }

        cookies.put("session", "abc123");
        cookies.put("user", "john_doe");

        long usedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.out.println("Memory used before cleanup: " + usedMemory / 1024 + " KB");

        cookies.clear();
        System.gc();

        long afterCleanupMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.out.println("Memory used after cleanup: " + afterCleanupMemory / 1024 + " KB");
        System.out.println("Memory cleaned up: " + (usedMemory - afterCleanupMemory) / 1024 + " KB");

        System.out.println("Cookies and memory cleared.");
    }
}
