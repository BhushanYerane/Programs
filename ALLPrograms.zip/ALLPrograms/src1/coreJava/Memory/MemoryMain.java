package coreJava.Memory;

public class MemoryMain {
    public static void main(String[] args) 
    {
        MemoryMonitor monitor = new MemoryMonitor();
        monitor.start();

        try {
            MemoryManager.cleanUp();
        } finally {
            monitor.stopMonitoring();
        }
    }
}
