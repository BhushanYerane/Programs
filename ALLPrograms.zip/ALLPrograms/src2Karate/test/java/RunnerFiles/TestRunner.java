package RunnerFiles;

import org.junit.jupiter.api.Test;
import com.intuit.karate.junit5.karate;


public class TestRunner {
	
	@Test
	public void runTest()
	{
		Katate.run("getRequest").
	}

}
