package com.FootballAPI;


import io.cucumber.junit.CucumberOptions;

@CucumberOptions
public class FootballAPIRunner {

}
