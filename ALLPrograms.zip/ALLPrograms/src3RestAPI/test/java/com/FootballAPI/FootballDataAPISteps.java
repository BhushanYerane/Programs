package com.FootballAPI;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class FootballDataAPISteps {

    private static final String BASE_URL = "http://api.football-data.org/v4";
    private static final String API_TOKEN = "a37bc520f4c14c788d216cbf7d093c69";
    private Response response;
    private static RequestSpecification requestSpec;
    private static String competitionId;

    @Given("The API base URL is set")
    public void the_api_base_url_is_set() {
        RestAssured.baseURI = BASE_URL;

        requestSpec = new RequestSpecBuilder()
                .addHeader("X-Auth-Token", API_TOKEN)
                .addFilter(new RequestLoggingFilter())
                .addFilter(new ResponseLoggingFilter())
                .build();
    }

    @When("I send a GET request to {string}")
    public void i_send_a_get_request_to(String endpoint) {
        response = given().spec(requestSpec).when().get(endpoint);
    }

    @Then("The response status code should be {int}")
    public void the_response_status_code_should_be(int statusCode) {
        response.then().statusCode(statusCode);
    }

    @Then("The response should contain a list of competitions")
    public void the_response_should_contain_a_list_of_competitions() {
        response.then().body("competitions", notNullValue());
    }

    @When("I send a POST request to {string} with payload")
    public void i_send_a_post_request_to_with_payload(String endpoint, DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        Map<String, String> payload = data.get(0);

        response = given().spec(requestSpec)
                .body(payload)
                .when()
                .post(endpoint);
    }

    @Then("The response should contain the competition name {string}")
    public void the_response_should_contain_the_competition_name(String competitionName) {
        response.then().body("name", equalTo(competitionName));
    }

    @Given("I have a competition ID")
    public void i_have_a_competition_id() {
        // Retrieve the competition ID from a previous response or set a known ID
        competitionId = "2001"; // Example ID, replace with actual ID retrieval
    }

    @When("I send a PUT request to {string} with payload")
    public void i_send_a_put_request_to_with_payload(String endpoint, DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        Map<String, String> payload = data.get(0);

        response = given().spec(requestSpec)
                .body(payload)
                .when()
                .put(endpoint.replace("{id}", competitionId));
    }

    @When("I send a DELETE request to {string}")
    public void i_send_a_delete_request_to(String endpoint) {
        response = given().spec(requestSpec)
                .when()
                .delete(endpoint.replace("{id}", competitionId));
    }

    @Then("The competition should be deleted")
    public void the_competition_should_be_deleted() {
        // Verify that the competition has been deleted
        // This can be done by sending a GET request to the endpoint and checking the response
        response = given().spec(requestSpec)
                .when()
                .get("/competitions/" + competitionId);

        response.then().statusCode(404);
    }

    @Then("The response should contain a list of matches")
    public void the_response_should_contain_a_list_of_matches() {
        response.then().body("matches", notNullValue());
    }

    @Then("The response should contain player ID {string}")
    public void the_response_should_contain_player_id(String playerId) {
        response.then().body("player.id", equalTo(playerId));
    }
}
