package com.basic;

import io.cucumber.java.en.Then;


public class MyBasicFile1 {
	
	@Then("submit buttton check")
	public void submit_buttton_check() {
	    System.out.println("validating submit button");
	}
	
}