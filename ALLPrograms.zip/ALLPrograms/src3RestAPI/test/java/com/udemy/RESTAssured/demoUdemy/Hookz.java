package com.udemy.RESTAssured.demoUdemy;

import java.io.IOException;

import io.cucumber.java.*;
import io.cucumber.java.Before;
import io.cucumber.java.After;

public class Hookz {
	
	PlaceValidationSteps sd;
	
	@Before()
	public void beforeScenario() throws IOException
	{
		sd = new PlaceValidationSteps(); 
		if(PlaceValidationSteps.place_id == null)
		{
		sd.add_place_payload("ASDF","Marathi","MUMbai_PUne");
		sd.user_calls_with_http_request("AddPlaceAPI", "post");
		sd.verify_place_id_creates_maps_to_using("ASDF", "GetPlaceAPI");
		}
	}
	
	@After
	public void afterScenario()
	{
		
	}

}
