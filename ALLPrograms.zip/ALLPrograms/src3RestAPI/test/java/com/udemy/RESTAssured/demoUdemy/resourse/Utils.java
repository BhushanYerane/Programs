package com.udemy.RESTAssured.demoUdemy.resourse;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
//RestAssured.baseURI = "https://rahulshettyacademy.com";

public class Utils { 
	
	public static RequestSpecification reqSpec;
	public static ResponseSpecification respSpec;
	
	public RequestSpecification requestSpecification() throws IOException
	{
		if(reqSpec == null)
		{
		PrintStream log = new PrintStream(new FileOutputStream("logging.txt"));
		reqSpec = new RequestSpecBuilder()
				.setBaseUri(getGlobalValue("baseURL")).addQueryParam("Key","qaclick123")
				.addFilter(RequestLoggingFilter.logRequestTo(log))
				.addFilter(ResponseLoggingFilter.logResponseTo(log))
				.setContentType(ContentType.JSON)
				.build();
		return reqSpec;
		}
		return reqSpec;
	}
	
	
	public static String getGlobalValue(String key) throws IOException
	{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("C:\\Users\\byerane\\eclipse-workspace\\RestAssured\\src\\test\\java\\com\\udemy\\RESTAssured\\demoUdemy\\resourse\\global.properties");
		prop.load(fis);
		return prop.getProperty(key);
	}
	
	public static RequestSpecification getRequestSpec() throws IOException 
	{
		
		if(reqSpec==null)
		{
			reqSpec = new RequestSpecBuilder().setBaseUri(getGlobalValue("baseurl1"))
						.addHeader("Authorization", "Bearer "+getGlobalValue("token1"))
						.setContentType(ContentType.JSON).log(LogDetail.ALL).build();
			return reqSpec;
		}
		
		return reqSpec;
	}
	
	public static ResponseSpecification getRespponseSpec(int expectedStatusCode) throws IOException
	{	
		ResponseSpecification respSpec =  new ResponseSpecBuilder().expectStatusCode(expectedStatusCode)
				.expectContentType(ContentType.JSON).build();
		return respSpec;
	}
	
	public String getJsonPath(Response response,String key)
	{
		String resp=response.asString();
		if (resp == null || resp.trim().isEmpty()) {
			throw new IllegalArgumentException("Response body is null or empty. Cannot parse JSON.");
		}
		JsonPath   js = new JsonPath(resp);
		//return js.get(key).toString();
		
		Object value = js.get(key);
		if (value == null) {
            throw new IllegalArgumentException("Key '" + key + "' not found in the JSON response.");
        }
		
		 return value.toString();

	}
}






/** 
 public RequestSpecification requestSpecification() throws FileNotFoundException {
    // Create log file to store request/response logs
    PrintStream log = new PrintStream(new FileOutputStream(new File("logging.txt")));
    
    // Initialize the RequestSpecification using RequestSpecBuilder
    RequestSpecification reqSpec = new RequestSpecBuilder()
            .setBaseUri("https://rahulshettyacademy.com")  // Base URL of the API
            .addQueryParam("Key", "qaclick123")  // Add query parameter (if required by your API)
            .addFilter(RequestLoggingFilter.logRequestTo(log))  // Log requests to logging.txt
            .addFilter(ResponseLoggingFilter.logResponseTo(log))  // Log responses to logging.txt
            .setContentType(ContentType.JSON)  // Set the content type to JSON
            .build();  // Build and return the RequestSpecification object

    return reqSpec;
}
 * */
