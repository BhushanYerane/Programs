package com.udemy.RESTAssured.files;

public class mobileTest {
	
	private String courseTitle;
	private String coursePrice;
	
	public String getCourseTitle() {
		return courseTitle;
	}
	public void setCourseTitle(String title) {
		this.courseTitle = title;
	}
	public String getCoursePrice() {
		return coursePrice;
	}
	public void setCoursePrice(String price) {
		this.coursePrice = price;
	}

}
