package com.udemy.RESTAssured.demoUdemy.resourse;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel2 {

	public static void main(String[] args) {
		String filePath = "C:\\Users\\byerane\\Downloads\\Backup\\Hydree\\NAART_Plan.xlsx";
		//String specificSheet = null; // Set to null to scan all sheets
		String specificSheet = "data1";

		try {
			scanWorkbookAndReadSheets(filePath, specificSheet);
		} catch (IOException e) {
			System.out.println("Error reading Excel file: " + e.getMessage());
		} finally {
			clearMemory(); // ✅ Suggest memory cleanup
		}
	}

	// ✅ Scans workbook and reads either a specific sheet or all sheets with data
	public static void scanWorkbookAndReadSheets(String filePath, String specificSheet) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        XSSFWorkbook workbook = null;

        try {
            workbook = new XSSFWorkbook(fis);
            int numSheets = workbook.getNumberOfSheets();
            System.out.println("Total Sheets in Workbook: " + numSheets);

            if (specificSheet != null && !specificSheet.isEmpty()) {
                // ✅ Read only the specified sheet
                XSSFSheet sheet = workbook.getSheet(specificSheet);
                if (sheet != null && sheet.iterator().hasNext()) {
                    System.out.println("\n📄 Reading data from sheet: " + specificSheet);
                    readExcelData(sheet);
                } else {
                    System.out.println("⚠️ Sheet '" + specificSheet + "' is empty or not found.");
                }
            } else {
                // ✅ Scan and read all sheets with data
                for (int i = 0; i < numSheets; i++) {
                    XSSFSheet sheet = workbook.getSheetAt(i);
                    String sheetName = sheet.getSheetName();

                    if (sheet.iterator().hasNext()) {
                        System.out.println("\n📄 Reading data from sheet: " + sheetName);
                        readExcelData(sheet);
                    } else {
                        System.out.println("⚠️ Sheet '" + sheetName + "' is empty.");
                    }
                }
            }
        } finally {
            if (workbook != null) workbook.close();
            if (fis != null) fis.close();
        }
    }

	// ✅ Reads and prints data from a given sheet
	public static void readExcelData(XSSFSheet sheet) {
		Iterator<Row> rowIterator = sheet.iterator();

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			int rowNum = row.getRowNum();

			Iterator<Cell> cellIterator = row.cellIterator();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				int colNum = cell.getColumnIndex();

				if (cell.getCellType() != CellType.BLANK) {
					System.out.println("Row: " + rowNum + ", Column: " + colNum + " -> Value: " + cell.toString());
				}
			}
		}

		// 🔽 You can add custom logic here to filter or format output
	}

	// ✅ Suggests memory cleanup to JVM
	public static void clearMemory() {
		System.gc();
		System.out.println("🧹 Memory cleanup suggested to JVM.");
	}
}
