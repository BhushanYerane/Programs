package com.udemy.RESTAssured.demoUdemy;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import com.udemy.RESTAssured.demoUdemy.resourse.APIResources;
import com.udemy.RESTAssured.demoUdemy.resourse.TestDataBuild;
import com.udemy.RESTAssured.demoUdemy.resourse.Utils;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class PlaceValidationSteps extends Utils {
	
	ResponseSpecification respSpec;
	RequestSpecification res;
	Response resp;
	TestDataBuild data = new TestDataBuild();
	static String place_id;
	
	@Given("Add place payload")
	public void add_place_payload() throws IOException {
		RestAssured.useRelaxedHTTPSValidation();
		res = given().spec(requestSpecification()).body(data.addPlacePayloads());
	}
	
	@Given("Add place payload {string} {string} {string}")
	public void add_place_payload(String name1, String language1, String address1) throws IOException {
		RestAssured.useRelaxedHTTPSValidation();
		res = given().spec(requestSpecification()).body(data.addPlacePayloads(name1,language1,address1));
	}

	@When("user calls {string} with post http request")
	public void user_calls_with_post_http_request(String resource) {
		APIResources resourceAPI = APIResources.valueOf(resource);
		respSpec = new ResponseSpecBuilder()
            	.expectStatusCode(200)
            	.expectContentType(ContentType.JSON)
            	.build();
		//resp = res.when().post("/maps/api/place/add/json").then().spec(respSpec).extract().response();    
		resp = res.when().post(resourceAPI.getResource()).then().spec(respSpec).extract().response();
	}
	
	@When("user calls {string} with {string} http request")
	public void user_calls_with_http_request(String resource, String methodz)  throws IOException {
		APIResources resourceAPI = APIResources.valueOf(resource);
		respSpec = new ResponseSpecBuilder()
            	.expectStatusCode(200)
            	.expectContentType(ContentType.JSON)
            	.build();
		System.out.println(resourceAPI.getResource());
		
		if(methodz.equalsIgnoreCase("post"))
			resp =res.when().post(resourceAPI.getResource());
		else if(methodz.equalsIgnoreCase("get"))
			resp = res.when().get(resourceAPI.getResource());
		else if (methodz.equalsIgnoreCase("delete"))
			resp = res.when().delete(resourceAPI.getResource());
	}

	@Then("the API call success with status code {int}")
	public void the_api_call_success_with_status_code(Integer int1) {
		assertEquals(resp.getStatusCode(),200);
	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String keyValue, String Expectvalue) {
		String response = resp.asString();
		JsonPath jsp = new JsonPath(response);
		String status = jsp.get("status");
		String scope = jsp.get("scope");
		
		assertEquals(jsp.get(keyValue).toString(),Expectvalue);
		
		System.out.println("Status: "+ status +", scope: "+scope);
	}
	
	@Then("verify place_Id creates maps to {string} using {string}")
	public void verify_place_id_creates_maps_to_using(String expectedName, String resoursename) throws IOException {
	    place_id  = getJsonPath(resp,"place_id");
	    res = given().spec(requestSpecification()).queryParam("place_id",place_id);
	    user_calls_with_http_request(resoursename,"get");
	    
	    resp.then().log().all();
	    if (resp.getStatusCode() != 200) {
	        throw new RuntimeException("API call failed with status code: " + resp.getStatusCode());
	    }
	    System.out.println(resp);
	    String actualname1 = getJsonPath(resp,"name");
	    assertEquals(actualname1,expectedName);
	}

	@Given("DeletePlace Playload")
	public void delete_place_playload() throws IOException
	{
		res = given().spec(requestSpecification()).body(data.deleteplacepayload(place_id));	
		resp.then().log().all();
	}
}
