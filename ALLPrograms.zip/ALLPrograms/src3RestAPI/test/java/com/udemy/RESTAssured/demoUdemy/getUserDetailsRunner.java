package com.udemy.RESTAssured.demoUdemy;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/test/resources/demoUdemy/getUserDeatils.feature"},
		glue = {"com.udemy.RestAssured.demoUdemy"},
		dryRun = true,
		monochrome = true,
		plugin = {"pretty", "html:target/cucumber-reports.html","json:target/cucumber-report1.json"}
	//  ,tags = "",""	
		)

public class getUserDetailsRunner {

}
