package com.udemy.RESTAssured.demoUdemy;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.greaterThan;

import org.hamcrest.Matcher;
import org.jsoup.helper.HttpConnection.Request;

import com.udemy.RESTAssured.demoUdemy.resourse.TestDataBuild;

import static org.hamcrest.Matchers.*;

public class getUserStepsDef {
	
	private String base_URL;
    private String token;
    private String endpoint;
    Response response;
    RequestSpecification request;
    
    TestDataBuild data = new TestDataBuild();
	
	@Given("Base_URL {string}")
	public void base_url(String URL) {
	  base_URL = URL;
	}

	@Given("A Bearer Token {string}")
	public void a_bearer_token(String bearerToken) {
	    token = bearerToken;
	}

	@Given("A API end point is {string}")
	public void a_api_end_point_is(String apiEndpoint) {
		endpoint = apiEndpoint;
	}

	@When("I send a GET request to API endpoint")
	public void i_send_a_get_request_to_api_endpoint() {
		response = given().log().all().header("Authorization", "Bearer " + token).get(base_URL + endpoint);
//		response = given(SpecBuilder.getRequestSpec()).when().get()
	}

	@Then("response status should be {int}")
	public void response_status_should_be(Integer statuscode) {
		response.then().statusCode(statuscode);
	}

	@Then("the response should contain a list of users")
	public void the_response_should_contain_a_list_of_users() {
	   response.then().log().all().body("size()", greaterThan(0));
	}
	
	@Given("the request payload")
	public void the_request_payload() {
//	  given().contentType(ContentType.JSON).body(data.newuserpayload());
		request = given().contentType(ContentType.JSON).body(data.newuserpayload());
	}
	
	@Given("the request payload {string} {string} {string} {string}")
	public void the_request_payload(String email, String name, String gender, String status) {
//		given().contentType(ContentType.JSON).body(data.newuserpayload1(email,name, gender, status));
		request = given().contentType(ContentType.JSON).body(data.newuserpayload(email,name, gender, status));
	}

	@When("I send a POST request to API endpoint")
	public void i_send_a_post_request_to_api_endpoint() {
//		response = given().log().all().header("Authorization", "Bearer " + token).post(base_URL + endpoint);
		response = request.log().all().header("Authorization", "Bearer " + token).post(base_URL + endpoint);
	}

	@Then("response status should {int}")
	public void response_status_should(Integer statuscode) {
	    response.then().log().all().statusCode(statuscode);
	}

	@Then("the response should contain the user details")
	public void the_response_should_contain_the_user_details() {
		response.then().log().all().body("id", notNullValue())
        		.body("name", equalTo("Bhushan Lala"))
        		.body("email", equalTo("lala@yahoo.com"));
	}
}