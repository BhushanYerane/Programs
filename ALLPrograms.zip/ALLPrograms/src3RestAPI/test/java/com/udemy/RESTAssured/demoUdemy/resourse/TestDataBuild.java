package com.udemy.RESTAssured.demoUdemy.resourse;

import java.util.ArrayList;
import java.util.List;

import pojo.AddPlace;
import pojo.Location;

import pojo.CreateUser;

public class TestDataBuild {
	
	public AddPlace addPlacePayloads()
	{
		AddPlace p = new AddPlace();
		p.setName("Frontline house");
		p.setAddress("29, side layout, cohen 09");
		p.setPhone_number("(+91) 983 893 3937");
		p.setLanguage("French-IN");
		p.setWebsite("http://www.google.com");
		p.setAccuracy(50);
		List<String> myList = new ArrayList<String>();
		myList.add("shoe park");
		myList.add("shop");
		p.setTypes(myList);
		
		Location l = new Location();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		p.setLocation(l);
		
		return p;
	}
	
	public AddPlace addPlacePayloads(String name1, String language1, String address1)
	{
		AddPlace p = new AddPlace();
		p.setName(name1);
		p.setAddress(language1);
		p.setLanguage(address1);
		p.setPhone_number("(+91) 983 893 3937");
		p.setWebsite("http://www.google.com");
		p.setAccuracy(50);
		List<String> myList = new ArrayList<String>();
		myList.add("shoe park");
		myList.add("shop");
		p.setTypes(myList);
		
		Location l = new Location();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		p.setLocation(l);
		
		return p;
	}
	
	public String deleteplacepayload(String placeID) // "+<text>+"
	{
		return "{\r\n" 
					+ "  \"place_id\": \"" + placeID + "\"\r\n" 
					+ "}";	
	}


	public CreateUser newuserpayload()
	{
		CreateUser cu = new CreateUser();
		cu.setEmail("lala@yahoo.org");
		cu.setGender("Male");
		cu.setName("Bhushan Lala");
		cu.setStatus("active");
		
		return cu;
	}
	
	public CreateUser newuserpayload(String email1, String name1, String gen1, String status1)
	{
		CreateUser cu = new CreateUser();
		cu.setEmail(email1);
		cu.setGender(gen1);
		cu.setName(name1 +" Lala JI");
		cu.setStatus(status1);
		
		return cu;
	}

	
}
