package com.udemy.RESTAssured.files;

public class batterTest {
	
	private int ID;
	private String type;
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
