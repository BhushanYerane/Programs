package com.udemy.RESTAssured.files;

public class OrderDetail{
	
	private String Country;
	private String productOrderID;
	
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getProductOrderID() {
		return productOrderID;
	}
	public void setProductOrderID(String productOrderID) {
		this.productOrderID = productOrderID;
	}
	

}
