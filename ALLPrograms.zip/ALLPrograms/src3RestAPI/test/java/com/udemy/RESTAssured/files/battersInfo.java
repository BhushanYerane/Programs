package com.udemy.RESTAssured.files;

import java.util.List;

public class battersInfo {
    private List<batterTest> batter;

    public List<batterTest> getBatter() {
        return batter;
    }

    public void setBatter(List<batterTest> batter) {
        this.batter = batter;
    }
}
