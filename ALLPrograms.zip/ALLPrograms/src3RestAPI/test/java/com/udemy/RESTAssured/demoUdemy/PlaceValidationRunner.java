package com.udemy.RESTAssured.demoUdemy;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class) 
@CucumberOptions(
			features = {"src/test/resources/demoUdemy/placeValidation.feature"},
			glue = {"com.udemy.RESTAssured.demoUdemy"},
			dryRun = false,
			monochrome = true,
			plugin={"pretty","html:target/cucumber-htmlreport",	"json:target/jsonReports/cucumber-report.json"}
		)
public class PlaceValidationRunner {

}
