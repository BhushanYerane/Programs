package com.udemy.RESTAssured.demoUdemy.resourse;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelReadClass {

    private static final String FILE_PATH = "C:\\Users\\byerane\\Downloads\\Backup\\Hydree\\NAART_Plan.xlsx";
    private static final String SHEET_NAME = "Sheet5";
    private static final int COLUMN_INDEX = 0;

    public static void main(String[] args) {
        try {
            listSheetsAndCheckData(FILE_PATH); // ✅ List all sheets and check for data
            List<String> columnData = readColumnData(FILE_PATH, SHEET_NAME, COLUMN_INDEX);
            System.out.println("📋 Data from sheet '" + SHEET_NAME + "':");
            columnData.forEach(System.out::println);
        } catch (IOException e) {
            System.err.println("Error reading Excel file: " + e.getMessage());
        } finally {
            clearMemory();
        }
    }

    private static void clearMemory() {
        System.gc();
        System.out.println("🧹 Memory cleanup suggested to JVM.");
    }

    /**
     * Reads and prints only non-empty rows and columns from the specified sheet.
     */
    public static List<String> readColumnData(String filePath, String sheetName, int columnIndex) throws IOException {
        List<String> columnValues = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                System.err.println("Sheet '" + sheetName + "' not found.");
                return columnValues;
            }

            for (Row row : sheet) {
                if (row == null || row.getPhysicalNumberOfCells() == 0) {
                    continue;
                }

                StringBuilder rowData = new StringBuilder("Row " + row.getRowNum() + ": ");
                boolean hasData = false;

                for (Cell cell : row) {
                    String cellValue = "";
                    if (cell != null) {
                        CellType cellType = cell.getCellType();
                        if (cellType == CellType.STRING) {
                            cellValue = cell.getStringCellValue().trim();
                        } else if (cellType == CellType.NUMERIC) {
                            if (DateUtil.isCellDateFormatted(cell)) {
                                cellValue = cell.getDateCellValue().toString();
                            } else {
                                cellValue = String.valueOf(cell.getNumericCellValue());
                            }
                        } else if (cellType == CellType.BOOLEAN) {
                            cellValue = String.valueOf(cell.getBooleanCellValue());
                        } else if (cellType == CellType.FORMULA) {
                            cellValue = cell.getCellFormula();
                        }
                    }

                    if (!cellValue.isEmpty()) {
                        rowData.append("[Col ").append(cell.getColumnIndex()).append(": ").append(cellValue).append("] ");
                        hasData = true;
                    }
                }
                if (hasData) {
                    String rowOutput = rowData.toString().trim();
                    columnValues.add(rowOutput);
                }
            }
        }
        return columnValues;
    }

    /**
     * Lists all sheets in the workbook and checks if each sheet contains data.
     */
    public static void listSheetsAndCheckData(String filePath) throws IOException {
        try (FileInputStream fis = new FileInputStream(filePath);
             XSSFWorkbook workbook = new XSSFWorkbook(fis)) {

            int numberOfSheets = workbook.getNumberOfSheets();
            System.out.println("📘 Total Sheets: " + numberOfSheets);
            
            for(int i = 0; i < numberOfSheets; i++) {
            	String sheetName = workbook.getSheetAt(i).getSheetName();
            	System.out.println("🔹 Sheet " + (i + 1) + ": " + sheetName);
            }

            for (int i = 0; i < numberOfSheets; i++) {
                Sheet sheet = workbook.getSheetAt(i);
                String sheetName = sheet.getSheetName();
                boolean hasData = false;

                for (Row row : sheet) {
                    if (row != null && row.getPhysicalNumberOfCells() > 0) {
                        hasData = true;
                        break;
                    }
                }
                System.out.println("🔍 Sheet '" + sheetName + "' has data: " + hasData);
            }
        }
    }
}
