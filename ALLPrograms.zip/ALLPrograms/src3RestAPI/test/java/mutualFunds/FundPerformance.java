package mutualFunds;

public class FundPerformance {
    private int year;
    private double returns;

    // Getters and setters
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getReturn() {
        return returns;
    }

    public void setReturn(double return1) {
        this.returns = return1;
    }
}
