package mutualFunds;

public class Subtopic {
    private String subtopic;

    // Getters and setters
    public String getSubtopic() {
        return subtopic;
    }

    public void setSubtopic(String subtopic) {
        this.subtopic = subtopic;
    }
}

