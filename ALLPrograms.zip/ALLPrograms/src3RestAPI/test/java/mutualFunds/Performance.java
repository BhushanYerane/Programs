package mutualFunds;

import java.util.List;

public class Performance {
    private List<FundPerformance> yearly;

    // Getters and setters
    public List<FundPerformance> getYearly() {
        return yearly;
    }

    public void setYearly(List<FundPerformance> yearly) {
        this.yearly = yearly;
    }
}

