package Z99;

import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserTest extends TestBase {

    @Test
    public void getUserById() {
        Response response = setup()
                .get("users/6940551").then().log().all().extract().response();

        // Print response for debugging
        response.prettyPrint();

        // Assertions
        assertEquals(200, response.statusCode());
        assertEquals(6940551, response.jsonPath().getInt("id"));
    }
}
