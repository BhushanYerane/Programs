package Z99;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class TestBase {

    public RequestSpecification setup() {
        return RestAssured
                .given()
                .baseUri(APIConfig.BASE_URL)
                .header("Authorization", "Bearer " + APIConfig.TOKEN)
                .header("Content-Type", "application/json");
    }
}
