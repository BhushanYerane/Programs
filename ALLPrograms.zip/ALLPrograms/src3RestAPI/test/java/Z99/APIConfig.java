package Z99;

public class APIConfig {
    public static final String BASE_URL = "https://gorest.co.in/public/v2/";
    public static final String TOKEN = "7d4707316afdb12fa54510025dd70739ebb26d3732cd797093baa15a6dfe4cbd";  
}
