package Mastercard;

public class MerchantIdentifierPayload {

    private String merchantId;
    private String name;
    private String address;
    private String city;
    private String country;

    // Constructor for GET request
    public MerchantIdentifierPayload(String merchantId) {
        this.merchantId = merchantId;
    }

    // Constructor for POST request
    public MerchantIdentifierPayload(String merchantId, String name, String address, String city, String country) {
        this.merchantId = merchantId;
        this.name = name;
        this.address = address;
        this.city = city;
        this.country = country;
    }

    // Getters and Setters
    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}