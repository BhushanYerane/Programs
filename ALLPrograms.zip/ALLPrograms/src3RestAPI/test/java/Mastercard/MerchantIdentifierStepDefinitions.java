package Mastercard;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import io.restassured.response.Response;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

public class MerchantIdentifierStepDefinitions {

    RequestSpecification requestSpec;
    ResponseSpecification responseSpec;
    Response response;
    MerchantIdentifierPayload payload;

    @Given("the base URI is set for Mastercard API")
    public void the_base_URI_is_set_for_Mastercard_API() {
        RestAssured.baseURI = "https://sandbox.api.mastercard.com";
    }

    @Given("the merchant identifier payload is set for GET request")
    public void the_merchant_identifier_payload_is_set_for_GET_request() {
        payload = new MerchantIdentifierPayload("some_merchant_id");
        requestSpec = new RequestSpecBuilder()
            .setBaseUri(RestAssured.baseURI)
            .setContentType(ContentType.JSON)
            .addQueryParam("merchant_id", payload.getMerchantId())
            .build();

        responseSpec = new ResponseSpecBuilder()
            .expectStatusCode(200)
            .expectContentType(ContentType.JSON)
            .build();
    }

    @Given("the merchant identifier payload is set for POST request")
    public void the_merchant_identifier_payload_is_set_for_POST_request() {
        payload = new MerchantIdentifierPayload("new_merchant_id", "New Merchant Name", "123 Street", "City", "Country");

        requestSpec = new RequestSpecBuilder()
            .setBaseUri(RestAssured.baseURI)
            .setContentType(ContentType.JSON)
            .build();

        responseSpec = new ResponseSpecBuilder()
            .expectStatusCode(201)
            .expectContentType(ContentType.JSON)
            .build();
    }

    @When("the GET request is sent")
    public void the_GET_request_is_sent() {
        response = given().spec(requestSpec)
            .when().get("/merchantid/v1/merchant");

        response.then().spec(responseSpec);
    }

    @When("the POST request is sent")
    public void the_POST_request_is_sent() {
        response = given().spec(requestSpec)
            .body(payload)
            .when().post("/merchantid/v1/merchant");

        response.then().spec(responseSpec);
    }

    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(int statusCode) {
        assertEquals(statusCode, response.getStatusCode());
    }

    @Then("the merchant details should be retrieved successfully")
    public void the_merchant_details_should_be_retrieved_successfully() {
    	MerchantIdentifierPayload responseBody = response.getBody().as(MerchantIdentifierPayload.class);
    	assertEquals(200, response.getStatusCode());
    	assertEquals("application/json", response.getHeader("Content-Type"));
    	assertEquals("expectedMerchantName", responseBody.getName());
   }

    @Then("the merchant should be added successfully")
    public void the_merchant_should_be_added_successfully() {
    	MerchantIdentifierPayload responseBody = response.getBody().as(MerchantIdentifierPayload.class);
    	assertEquals(201, response.getStatusCode());
    	
    }
}



//MerchantIdentifierResponse responseBody = response.getBody().as(MerchantIdentifierResponse.class);
//assertEquals(200, response.getStatusCode());
//assertEquals(201, response.getStatusCode());
//assertEquals("application/json", response.getHeader("Content-Type"));
//assertEquals("expectedMerchantName", responseBody.getName());
//assertEquals("expectedCity", responseBody.getCity());
//assertEquals("expectedCountry", responseBody.getCountry());
//List<Item> items = responseBody.getItems();
//assertEquals(2, items.size());
//
//assertEquals("item1", items.get(0).getName());
//assertEquals("item2", items.get(1).getName());
//Location location = responseBody.getLocation();
//assertEquals("expectedLatitude", location.getLatitude());
//assertEquals("expectedLongitude", location.getLongitude());
//response.then().assertThat().body(matchesJsonSchemaInClasspath("schema.json"));
//MerchantIdentifierResponse responseBody = response.getBody().as(MerchantIdentifierResponse.class);
//assertEquals("Frontline house", responseBody.getName());
//assertEquals("29, side layout, cohen 09", responseBody.getAddress());
//assertEquals("French-IN", responseBody.getLanguage());

