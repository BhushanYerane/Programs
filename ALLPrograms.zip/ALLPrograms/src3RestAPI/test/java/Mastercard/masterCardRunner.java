package Mastercard;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/com/mastercard", // Path to your feature files
        glue = {"Mastercard"}, // Package name where the step definitions are located
        plugin = {"pretty", "html:target/cucumber-reports.html", "json:target/cucumber-reports/cucumber.json"}, // Reporting plugins
        monochrome = true, // Display the console output in a readable way
        dryRun = false // Set to true to check the mapping between feature file and step definitions
        //tags = "@SmokeTest" // You can use tags to run specific scenarios
)
public class masterCardRunner {
    // This class remains empty, it is used only as a holder for the above annotations
}
