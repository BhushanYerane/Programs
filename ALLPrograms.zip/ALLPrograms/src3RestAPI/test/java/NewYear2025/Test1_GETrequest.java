package NewYear2025;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class Test1_GETrequest {

    public static void main(String[] args) {
        
    	 // Set the base URI
    	 // Set the base URI
        RestAssured.baseURI = "https://dummy-json.mock.beeceptor.com";
        
        // Perform the GET request and validate the response
        given()
            .header("Content-Type", "application/json")
            .log().all()
        .when()
            .get("/posts")
        .then()
            .log().all()
            .assertThat()
            .statusCode(200)
            .body("userId", equalTo(1))
            .body("title", equalTo("Introduction to Artificial Intelligence"))
            .body("comment_count", equalTo(8));
        
        // Perform the GET request and validate the response with id
        given()
            .header("Content-Type", "application/json")
            .log().all()
        .when()
            .get("/posts/10")
        .then()
            .log().all()
            .assertThat()
            .statusCode(200)
            .body("status", equalTo(200))
            .body("userId", equalTo(1))
            .body("title", equalTo("Introduction to Artificial Intelligence"))
            .body("comment_count", equalTo(8));
    }
}
