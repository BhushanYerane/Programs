package RestAssuredTest;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class Demo4_DeleteRequest {
	
	int empID = 11235;
	
	@Test
	public void testDelete()
	{
		RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1";
		RestAssured.basePath = "/delete/"+empID;
		
		Response response =	given()
								.log().all()
							.when()
								.delete()
							.then().log().all()
								.statusCode(200)
								.statusLine("HTTP/1.1 200 OK").extract().response();
		
		String jsonAsString  = response.asString();
		Assert.assertEquals(jsonAsString.contains("Successfully! Record has been deleted"), true);
	}
	
	

}
