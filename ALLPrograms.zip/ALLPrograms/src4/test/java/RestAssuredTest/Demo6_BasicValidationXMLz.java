package RestAssuredTest;

import static io.restassured.RestAssured.*;
import static org.hamcrest.CoreMatchers.equalTo;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;

import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;

public class Demo6_BasicValidationXMLz 
{
	static {
        RestAssured.baseURI = "https://gorest.co.in/public/v1";
    }

    private static final String ACCESS_TOKEN = "7d4707316afdb12fa54510025dd70739ebb26d3732cd797093baa15a6dfe4cbd";

    @Test
    public void testStatusCode() {
        given()
            .header("Authorization", "Bearer " + ACCESS_TOKEN)
            .param("page", 1)
        .when()
            .get("/users")
        .then().log().all()
            .statusCode(200);
    }
    
    @Test
    public void testLogging() {
        Response response = given()
            .header("Authorization", "Bearer " + ACCESS_TOKEN)
            .param("page", 1)
            .accept("application/xml")
        .when()
            .get("/users")
        .then().log().all()
            .statusCode(200)
            .extract().response();

        String responseString = response.asString();
        System.out.println("Response: " + responseString);
    }
    
    @Test
    public void testSingleContent() {
        Response response = given()
            .header("Authorization", "Bearer " + ACCESS_TOKEN)
            .param("page", 1)
            .accept("application/xml")
        .when()
            .get("/users")
        .then().log().all()
            .statusCode(200)
            .extract().response();

        XmlPath xmlPath = new XmlPath(response.asString());
        String firstUserName = xmlPath.getString("data[0].name");
      }

    @Test
    public void testMultipleContents() {
        Response response = given()
            .header("Authorization", "Bearer " + ACCESS_TOKEN)
            .param("page", 1)
            .accept("application/xml")
        .when()
            .get("/users")
        .then().log().all()
            .statusCode(200)
            .extract().response();

        XmlPath xmlPath = new XmlPath(response.asString());
        String firstUserName = xmlPath.getString("data[0].name");
        String firstUserEmail = xmlPath.getString("data[0].email");
        String firstUserGender = xmlPath.getString("data[0].gender");
      }

    @Test
    public void testAllContents() {
        Response response = given()
            .header("Authorization", "Bearer " + ACCESS_TOKEN)
            .param("page", 1)
            .accept("application/xml")
        .when()
            .get("/users")
        .then().log().all()
            .statusCode(200)
            .extract().response();

        XmlPath xmlPath = new XmlPath(response.asString());
        List<String> allUserNames = xmlPath.getList("data.name");
        List<String> allUserEmails = xmlPath.getList("data.email");
        List<String> allUserGenders = xmlPath.getList("data.gender");
    }

    @Test
    public void testXPath() {
        Response response = given()
            .header("Authorization", "Bearer " + ACCESS_TOKEN)
            .param("page", 1)
            .accept("application/xml")
        .when()
            .get("/users")
        .then().log().all()
            .statusCode(200)
            .extract().response();

        XmlPath xmlPath = new XmlPath(response.asString());
        String firstUserName = xmlPath.getString("data.user[0].name");
    }
    
    @Test
    void testMultipleContentsInOneGo()
    {
    	given()
    	.when()
    		.get("http://thomas-bayer.com/sqlrest/customer/15/")
    	.then()
    		.body("CUSTOMER.text()", equalTo("15Bill"));
    }
}
