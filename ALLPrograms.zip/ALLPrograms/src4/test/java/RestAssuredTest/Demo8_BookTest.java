package RestAssuredTest;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import RestAssuredTest.vlidator.BookXML_Serialization_Deserialization;

//BookXML_Serialization_Deserialization.java

public class Demo8_BookTest {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://example.com/api";
    }

    @Test
    public void testSerialization() {
    	BookXML_Serialization_Deserialization book = new BookXML_Serialization_Deserialization();
        book.setId(1);
        book.setTitle("The Great Gatsby");
        book.setAuthor("F. Scott Fitzgerald");
        book.setGenre("Fiction");
        book.setPrice(10.99);

        Response response = given()
        				.contentType(ContentType.XML)
        				.body(book)
        			.when()
        				.post("/books")
        			.then().log().all()
        			.extract().response();

        Assert.assertEquals(response.getStatusCode(), 201);
    }

    @Test
    public void testDeserialization() {
        Response response = given()
        		.when()
        			.get("/books/1")
        		.then().log().all()
        			.extract().response();;

        Assert.assertEquals(response.getStatusCode(), 200);

        BookXML_Serialization_Deserialization book = response.getBody().as(BookXML_Serialization_Deserialization.class);
        Assert.assertEquals(book.getId(), 1);
        Assert.assertEquals(book.getTitle(), "The Great Gatsby");
    }

    public static void main(String[] args) {
        Demo8_BookTest bookTest = new Demo8_BookTest();
        bookTest.setup();
        bookTest.testSerialization();
        bookTest.testDeserialization();
    }
}
