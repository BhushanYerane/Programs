package RestAssuredTest;

import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;

public class RandomDataGenerator {

    private static final String[] FIRST_NAMES = {"John", "Jane", "Alex", "Emily", "Michael", "Sarah", "David", "Laura"};
    private static final String[] LAST_NAMES = {"Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson"};
    private static final String[] EMAIL_DOMAINS = {"@yahoo.co.in", "@gmail.com", "@outlook.com", "@abc.xyz"};
    private static final String SPECIAL_CHARACTERS = "#$&";

    private static final Random RANDOM = new Random();

    public static void main(String[] args) {
        String firstName = getFirstName();
        String lastName = getLastName();
        String emailID = getEmailID(firstName, lastName);
        String username = getUsername(firstName);
        String password = getPassword();

        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Email ID: " + emailID);
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
    }

    public static String getFirstName() {
        return FIRST_NAMES[RANDOM.nextInt(FIRST_NAMES.length)];
    }

    public static String getLastName() {
        return LAST_NAMES[RANDOM.nextInt(LAST_NAMES.length)];
    }

    public static String getEmailID(String firstName, String lastName) {
        String domain = EMAIL_DOMAINS[RANDOM.nextInt(EMAIL_DOMAINS.length)];
        return firstName.toLowerCase() + "." + lastName.toLowerCase() + domain;
    }

    public static String getUsername(String firstName) {
        int number = RANDOM.nextInt(100);
        char specialChar = SPECIAL_CHARACTERS.charAt(RANDOM.nextInt(SPECIAL_CHARACTERS.length()));
        return firstName.toLowerCase() + number + specialChar;
    }

    public static String getPassword() {
        StringBuilder password = new StringBuilder();
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789" + SPECIAL_CHARACTERS;

        for (int i = 0; i < 8; i++) {
            password.append(characters.charAt(RANDOM.nextInt(characters.length())));
        }

        return password.toString();
    }
    
    public static String getFirstName1() {
        return "FirstName" + (int) (Math.random() * 1000);
    }

    public static String getLastName1() {
        return "LastName" + (int) (Math.random() * 1000);
    }

    public static String getEmailID1(String firstName, String lastName) {
        return firstName.toLowerCase() + "." + lastName.toLowerCase() + "@example.com";
    }

    public static String getUsername1(String base) {
        return base + (int) (Math.random() * 1000);
    }

    public static String getPassword1() {
        return "Password" + (int) (Math.random() * 1000);
    }
    
    public static String getEMPName() {
      return RandomStringUtils.randomAlphabetic(10);
    }

    public static String getEMPSalary() {
      return RandomStringUtils.randomNumeric(7);
    }

    public static String getEMPAge() {
      int age = 18 + (int)(Math.random() * ((75 - 18) + 1));
      return Integer.toString(age);
    }
}
