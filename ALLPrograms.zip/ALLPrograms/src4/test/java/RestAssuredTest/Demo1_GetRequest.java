package RestAssuredTest;

import static io.restassured.RestAssured.given;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.specification.RequestSpecification;

public class Demo1_GetRequest {

	private static final String BASE_URL = "https://gorest.co.in/public/v2";
	private static final String API_TOKEN = "7d4707316afdb12fa54510025dd70739ebb26d3732cd797093baa15a6dfe4cbd";
	private static RequestSpecification requestSpec;

	public static void setup() {
		RestAssured.baseURI = BASE_URL;

		requestSpec = new RequestSpecBuilder().addHeader("Authorization", "Bearer " + API_TOKEN)
				.addHeader("Content-Type", "application/json").addFilter(new RequestLoggingFilter())
				.addFilter(new ResponseLoggingFilter()).build();
	}
	
	@Test
	public void getUsers() {
		if (requestSpec == null) 
		{
			setup();
		}
		given()
			.spec(requestSpec)
		.when()
			.get("/users")
		.then()
			.statusCode(200).statusLine("HTTP/1.1 200 OK")
			.assertThat().body("size()", Matchers.greaterThan(0))
			.header("Content-Type", "application/json; charset=utf-8");
	}
	
	

}
