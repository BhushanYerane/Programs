package RestAssuredTest;

import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class Demo3_PutRequest {
	
	private static final String BASE_URL = "https://gorest.co.in/public/v2";
    private static final String API_TOKEN = "7d4707316afdb12fa54510025dd70739ebb26d3732cd797093baa15a6dfe4cbd";
    private static RequestSpecification requestSpec;
    private static Map<String, String> map = new HashMap<>();
    
    String empName = RandomDataGenerator.getEMPName();
    String empSalary = RandomDataGenerator.getEMPSalary();
    String empAge = RandomDataGenerator.getEMPAge();
    int empID = 11234;
	
	
	@BeforeClass
	public void putData()
	{
		map.put("Name", empName);
		map.put("Salary", empSalary);
		map.put("Age", empAge);
		
		RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1";
		RestAssured.basePath = "/update/"+empID;
	}
	
	@Test
	public void testPUT() 
	{
		given().log().all()
			.contentType("application/json")
			.body(map)
		.when()
			.put()
		.then().log().all()
			.statusCode(200);
	}

}
