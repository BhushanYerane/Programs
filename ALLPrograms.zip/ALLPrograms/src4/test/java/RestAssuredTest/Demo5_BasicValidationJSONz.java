package RestAssuredTest;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Demo5_BasicValidationJSONz {

	static {
		RestAssured.baseURI = "https://gorest.co.in/public/v2";
	}
	private static final String ACCESS_TOKEN = "7d4707316afdb12fa54510025dd70739ebb26d3732cd797093baa15a6dfe4cbd";

	@Test
	public void testStatusCode() {
			given()
			.when()
				.get("http://jsonplaceholder.typicode.com/posts/1")
			.then().log().all()
				.statusCode(200);

		Response response = given()
								.header("Authorization", "Bearer " + ACCESS_TOKEN)
								.param("page", 1)
							.when()
								.get("/users")
							.then().log().all()
								.extract().response();
		assertEquals(response.getStatusCode(), 200);
	}

	@Test
	public void testLogging() {
		Response response = given()
								.header("Authorization", "Bearer " + ACCESS_TOKEN)
								.param("page", 1)
							.when()
								.get("/users")
							.then().log().all()
								.statusCode(200)
									.extract()
									.response();

		JsonPath jsonPathEvaluator = response.jsonPath();
		String firstUserName = jsonPathEvaluator.get("data[0].name");
		System.out.println("First user's name: " + firstUserName);
	}

	@Test
	public void testSingleContent() {
		Response response = given()
								.header("Authorization", "Bearer " + ACCESS_TOKEN)
								.param("page", 1)
							.when()
								.get("/users")
							.then().log().all()
								.statusCode(200)
									.extract()
									.response();

		JsonPath jsonPathEvaluator = response.jsonPath();
		String firstUserName = jsonPathEvaluator.get("data[0].name");
		assertTrue(firstUserName != null && !firstUserName.isEmpty(), "First user's name should not be null or empty");

	}

	@Test
	public void testMultipleContents() {
		Response response = given()
								.header("Authorization", "Bearer " + ACCESS_TOKEN)
								.param("page", 1)
							.when()
								.get("/users")
							.then().log().all()
								.statusCode(200)
									.extract()
									.response();

		JsonPath jsonPathEvaluator = response.jsonPath();
		String firstUserName = jsonPathEvaluator.get("data[0].name");
		String firstUserEmail = jsonPathEvaluator.get("data[0].email");
		String firstUserGender = jsonPathEvaluator.get("data[0].gender");

		assertTrue(firstUserName != null && !firstUserName.isEmpty(), "First user's name should not be null or empty");
		assertTrue(firstUserEmail != null && !firstUserEmail.isEmpty(),
				"First user's email should not be null or empty");
		assertTrue(firstUserGender != null && !firstUserGender.isEmpty(),
				"First user's gender should not be null or empty");

	}
	
	

}
