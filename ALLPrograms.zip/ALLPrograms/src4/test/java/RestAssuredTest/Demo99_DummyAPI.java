package RestAssuredTest;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class Demo99_DummyAPI {

    // Base URI for all requests
    static {
        RestAssured.baseURI = "https://dummy.restapiexample.com/api/v1";
    }

    @Test
    public void testGetAllEmployees() {
        Response response = given().get("/employees");

        // Verify headers
        assertTrue(response.headers().hasHeaderWithName("Content-Type"));

        // Verify status code
        assertEquals(response.getStatusCode(), 200);

        // Verify status line
        assertEquals(response.getStatusLine(), "HTTP/1.1 200 OK");

        // Verify JSON response
        assertTrue(response.jsonPath().getList("data").size() > 0);
    }

    @Test
    public void testGetSingleEmployee() {
        Response response = given().get("/employee/1");

        // Verify headers
        assertTrue(response.headers().hasHeaderWithName("Content-Type"));

        // Verify status code
        assertEquals(response.getStatusCode(), 200);

        // Verify status line
        assertEquals(response.getStatusLine(), "HTTP/1.1 200 OK");

        // Verify JSON response
        assertEquals(response.jsonPath().getString("data.id"), "1");
    }

    @Test
    public void testCreateEmployee() {
        String requestBody = "{\"name\":\"test\",\"salary\":\"123\",\"age\":\"23\"}";

        Response response = given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .post("/create");

        // Verify headers
        assertTrue(response.headers().hasHeaderWithName("Content-Type"));

        // Verify status code
        assertEquals(response.getStatusCode(), 200);

        // Verify status line
        assertEquals(response.getStatusLine(), "HTTP/1.1 200 OK");

        // Verify JSON response
        assertEquals(response.jsonPath().getString("status"), "success");
    }

    @Test
    public void testUpdateEmployee() {
        String requestBody = "{\"name\":\"test\",\"salary\":\"1234\",\"age\":\"24\"}";

        Response response = given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .put("/update/21");

        // Verify headers
        assertTrue(response.headers().hasHeaderWithName("Content-Type"));

        // Verify status code
        assertEquals(response.getStatusCode(), 200);

        // Verify status line
        assertEquals(response.getStatusLine(), "HTTP/1.1 200 OK");

        // Verify JSON response
        assertEquals(response.jsonPath().getString("status"), "success");
    }

    @Test
    public void testDeleteEmployee() {
        Response response = given().delete("/delete/2");

        // Verify headers
        assertTrue(response.headers().hasHeaderWithName("Content-Type"));

        // Verify status code
        assertEquals(response.getStatusCode(), 200);

        // Verify status line
        assertEquals(response.getStatusLine(), "HTTP/1.1 200 OK");

        // Verify JSON response
        assertEquals(response.jsonPath().getString("status"), "success");
    }
}

