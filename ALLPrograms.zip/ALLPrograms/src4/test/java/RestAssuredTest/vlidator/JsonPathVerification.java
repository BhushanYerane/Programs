package RestAssuredTest.vlidator;

import io.restassured.path.json.JsonPath;
import org.testng.Assert;

public class JsonPathVerification {

    public static void main(String[] args) {
        // Load the JSON content from SampleJson class
        String jsonContent = SampleJson.getJsonData();

        // Parse the JSON content using JsonPath
        JsonPath jsonPath = new JsonPath(jsonContent);

        // Verify the content
        String firstName = jsonPath.getString("firstName");
        String lastName = jsonPath.getString("lastName");
        int age = jsonPath.getInt("age");
        String city = jsonPath.getString("address.city");
        String phoneNumber = jsonPath.getString("phoneNumbers[0].number");

        // Assertions
        Assert.assertEquals(firstName, "John");
        Assert.assertEquals(lastName, "Doe");
        Assert.assertEquals(age, 30);
        Assert.assertEquals(city, "New York");
        Assert.assertEquals(phoneNumber, "212 555-1234");

        // Print success message
        System.out.println("All JSON content verified successfully!");
    }
}
