package RestAssuredTest.vlidator;

import io.restassured.path.xml.XmlPath;
import org.testng.Assert;

public class XmlPathVerification {

    public static void main(String[] args) {
        // Load the XML content from SampleXml class
        String xmlContent = SampleXml.XML;

        // Parse the XML content using XmlPath
        XmlPath xmlPath = new XmlPath(xmlContent);

        // Verify the content
        String firstName = xmlPath.getString("person.firstName");
        String lastName = xmlPath.getString("person.lastName");
        int age = xmlPath.getInt("person.age");
        String city = xmlPath.getString("person.address.city");
        String phoneNumber = xmlPath.getString("person.phoneNumbers.phoneNumber[0].number");

        // Assertions
        Assert.assertEquals(firstName, "John");
        Assert.assertEquals(lastName, "Doe");
        Assert.assertEquals(age, 30);
        Assert.assertEquals(city, "New York");
        Assert.assertEquals(phoneNumber, "212 555-1234");

        // Print success message
        System.out.println("All XML content verified successfully!");
    }
}

