package RestAssuredTest.vlidator;

public class SampleXml {
    public static final String XML = "<person>\n" +
            "  <firstName>John</firstName>\n" +
            "  <lastName>Doe</lastName>\n" +
            "  <age>30</age>\n" +
            "  <address>\n" +
            "    <streetAddress>21 2nd Street</streetAddress>\n" +
            "    <city>New York</city>\n" +
            "    <state>NY</state>\n" +
            "    <postalCode>10021</postalCode>\n" +
            "  </address>\n" +
            "  <phoneNumbers>\n" +
            "    <phoneNumber>\n" +
            "      <type>home</type>\n" +
            "      <number>212 555-1234</number>\n" +
            "    </phoneNumber>\n" +
            "    <phoneNumber>\n" +
            "      <type>fax</type>\n" +
            "      <number>646 555-4567</number>\n" +
            "    </phoneNumber>\n" +
            "  </phoneNumbers>\n" +
            "</person>";
}

