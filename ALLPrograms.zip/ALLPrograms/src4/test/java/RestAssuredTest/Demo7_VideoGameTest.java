package RestAssuredTest;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import RestAssuredTest.vlidator.VideoGame_Serialization_Deserialization;

// VideoGame_Serialization_Deserialization.java

public class Demo7_VideoGameTest {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "https://www.videogamedb.uk/api";
    }

    @Test
    public void testSerialization() {
    	VideoGame_Serialization_Deserialization game = new VideoGame_Serialization_Deserialization();
        game.setId(101);
        game.setName("Pac-Man");
        game.setReleaseDate("1980-05-22");
        game.setReviewScore(85);
        game.setCategory("Arcade");
        game.setRating("Everyone");

        Response response = given()
        					.contentType(ContentType.JSON)
        					.body(game)
        				.when()
        					.post("/videogame")
        				.then().log().all()
        				.extract().response();
        				
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    @Test
    public void testDeserialization() {
        Response response = given()
            .when()
            	.get("/videogame/101")
            .then().log().all()
				.extract().response();

        Assert.assertEquals(response.getStatusCode(), 200);

        VideoGame_Serialization_Deserialization game = response.getBody().as(VideoGame_Serialization_Deserialization.class);
        Assert.assertEquals(game.getId(), 101);
        Assert.assertEquals(game.getName(), "Pac-Man");
    }
}

