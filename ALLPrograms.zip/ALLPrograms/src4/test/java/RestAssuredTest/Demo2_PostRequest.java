package RestAssuredTest;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.CoreMatchers.*;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.specification.RequestSpecification;

public class Demo2_PostRequest {
	private static final String BASE_URL = "https://gorest.co.in/public/v2";
    private static final String API_TOKEN = "7d4707316afdb12fa54510025dd70739ebb26d3732cd797093baa15a6dfe4cbd";
    private static RequestSpecification requestSpec;
    private static Map<String, String> map = new HashMap<>();
   
    @BeforeClass
    public void setup() 
    {
        RestAssured.baseURI = BASE_URL;

        requestSpec = new RequestSpecBuilder()
                .addHeader("Authorization", "Bearer " + API_TOKEN)
                .addHeader("Content-Type", "application/json")
                .addFilter(new RequestLoggingFilter())
                .addFilter(new ResponseLoggingFilter())
                .build();
    	}

    @BeforeClass
    public void postdata() {
        map.put("name", RandomDataGenerator.getFirstName() + " " + RandomDataGenerator.getLastName());
        map.put("email", RandomDataGenerator.getEmailID("Bhushan", "Llalaji"));
        map.put("gender", "male");
        map.put("status", "active");
    }
	
	 @Test
	    public void testPost() {
		 if (requestSpec == null) 
			{
				setup();
			}
	        given()
	            .spec(requestSpec)
	            .body(map)
	        .when()
	            .post("/users")
	        .then()
	            .statusCode(201)
	            .body("email", equalTo(map.get("email")))
	            .body("name", equalTo(map.get("name")))
	            .body("gender", equalTo("male"))
	            .body("status", equalTo("active"));
	    }
}
