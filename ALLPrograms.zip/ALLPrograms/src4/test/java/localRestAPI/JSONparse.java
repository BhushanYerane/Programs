package localRestAPI;

import org.testng.annotations.Test;

import io.restassured.path.json.JsonPath;

public class JSONparse {
	
	@Test
	public void parse_TestData() {
		
		JsonPath jspObj = new JsonPath(JSONpayLoads.SampleData());
		int page = jspObj.get("page");
		System.out.println(page);
		
		int total = jspObj.get("total");
		System.out.println(total);
		
		int id1 = jspObj.get("data[0].id");
		System.out.println(id1);
		
		int count = jspObj.getInt("data.size()");
		System.out.println(count);
		
		System.out.println("----------------------");
		
		for(int i=0;i<count;i++)
		{
			int id = jspObj.getInt("data["+i+"].id");
			String Colourname = jspObj.getString("data["+i+"].name");
			String colourCode = jspObj.getString("data["+i+"].color");
			
			System.out.println("ID :"+id);
			System.out.println("Colour Name :"+Colourname);
			System.out.println("Colour Code :"+colourCode);
			
			System.out.println("----------------------");
		}
		
		String text = jspObj.getString("support.text");
		System.out.println(text);
		
	}
}
