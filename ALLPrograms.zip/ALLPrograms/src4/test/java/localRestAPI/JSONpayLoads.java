package localRestAPI;

public class JSONpayLoads {
	
	public static String SampleData()
	{
		String payloads =" {\r\n"
				+ "       \"page\": 1,\r\n"
				+ "       \"per_page\": 6,\r\n"
				+ "       \"total\": 12,\r\n"
				+ "       \"total_pages\": 2,\r\n"
				+ "       \"data\": [\r\n"
				+ "           {\r\n"
				+ "               \"id\": 1,\r\n"
				+ "               \"name\": \"cerulean\",\r\n"
				+ "               \"year\": 2000,\r\n"
				+ "               \"color\": \"#98B2D1\",\r\n"
				+ "               \"pantone_value\": \"15-4020\"\r\n"
				+ "           },\r\n"
				+ "           {\r\n"
				+ "               \"id\": 2,\r\n"
				+ "               \"name\": \"fuchsia rose\",\r\n"
				+ "               \"year\": 2001,\r\n"
				+ "               \"color\": \"#C74375\",\r\n"
				+ "               \"pantone_value\": \"17-2031\"\r\n"
				+ "           },\r\n"
				+ "           {\r\n"
				+ "               \"id\": 3,\r\n"
				+ "               \"name\": \"true red\",\r\n"
				+ "               \"year\": 2002,\r\n"
				+ "               \"color\": \"#BF1932\",\r\n"
				+ "               \"pantone_value\": \"19-1664\"\r\n"
				+ "           },\r\n"
				+ "           {\r\n"
				+ "               \"id\": 4,\r\n"
				+ "               \"name\": \"aqua sky\",\r\n"
				+ "               \"year\": 2003,\r\n"
				+ "               \"color\": \"#7BC4C4\",\r\n"
				+ "               \"pantone_value\": \"14-4811\"\r\n"
				+ "           },\r\n"
				+ "           {\r\n"
				+ "               \"id\": 5,\r\n"
				+ "               \"name\": \"tigerlily\",\r\n"
				+ "               \"year\": 2004,\r\n"
				+ "               \"color\": \"#E2583E\",\r\n"
				+ "               \"pantone_value\": \"17-1456\"\r\n"
				+ "           },\r\n"
				+ "           {\r\n"
				+ "               \"id\": 6,\r\n"
				+ "               \"name\": \"blue turquoise\",\r\n"
				+ "               \"year\": 2005,\r\n"
				+ "               \"color\": \"#53B0AE\",\r\n"
				+ "               \"pantone_value\": \"15-5217\"\r\n"
				+ "           }\r\n"
				+ "       ],\r\n"
				+ "       \"support\": {\r\n"
				+ "           \"url\": \"https://reqres.in/#support-heading\",\r\n"
				+ "           \"text\": \"To keep ReqRes free, contributions towards server costs are appreciated!\"\r\n"
				+ "       }\r\n"
				+ "   }";
		return payloads;
	}
	
	public static String postData(String name, int age, String position) {
        String addData = "{\r\n"
                + "    \"name\":\"" + name + "\",\r\n"
                + "    \"age\":" + age + ",\r\n"
                + "    \"position\":\"" + position + "\"\r\n"
                + "}";
        return addData;
    }

}
