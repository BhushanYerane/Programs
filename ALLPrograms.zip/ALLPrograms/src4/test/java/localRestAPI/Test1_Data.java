package localRestAPI;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Test1_Data {
	
	@Test
	public void get_TestData()
	{
		Response resp = given()
						.when()
							.get("http://localhost:8080/api/employee")
						.then().log().all()
						.statusCode(200).extract().response();
		
		JsonPath  jsp = resp.jsonPath();
		int emp_id = jsp.getInt("[0].emp_id");
		System.out.println(emp_id);
		
		int count = jsp.getInt("size()");
		System.out.println(count);
	}
	
	@Test
	public void post_TestData()
	{
		Response resp = given()
                .header("Content-Type", "application/json")
                .body(JSONpayLoads.postData("Chaman", 30, "Blockchain"))
            .when()
                .post("http://localhost:8080/api/employee")
            .then().log().all()
                .statusCode(200)
                .extract().response();

		System.out.println(resp.asString());
	}
	
	@Test
	public void delete_TestData(int empId) {
        // Check if the record exists
        Response getResponse = given()
                                    .log().all()
                               .when()
                                    .get("http://localhost:8080/api/employee/352")
                               .then().log().all()
                                    .extract().response();
        
        if (getResponse.getStatusCode() == 200) {
            Response deleteResponse = given()
                                           .log().all()
                                      .when()
                                           .delete("http://localhost:8080/api/employee/352")
                                      .then().log().all()
                                           .extract().response();

            JsonPath jsp = deleteResponse.jsonPath();
            String message = jsp.getString("msg");
            System.out.println("Response message: " + message);
        } else {
        	 System.out.println("Error: Record with empId " + empId + " does not exist.");
        }
    }
}
