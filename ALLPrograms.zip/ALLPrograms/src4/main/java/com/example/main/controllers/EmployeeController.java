package com.example.main.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.EmployeeDto;
import com.example.demo.model.MsgDto;
import com.example.exception.ResourceNotFoundException;
import com.example.main.repository.EmployeeRepository;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	EmployeeRepository empRepository;

	@GetMapping("/employee")
	public ResponseEntity<List<EmployeeDto>> getEmployee() {
		List<Employee> employees = empRepository.findAll();
		List<EmployeeDto> empDtoList = new ArrayList<EmployeeDto>();
		EmployeeDto empDto = new EmployeeDto();
		for (Employee emp : employees) {
			empDto.setAge(emp.getAge());
			empDto.setEmp_id(emp.getEmp_id());
			empDto.setName(emp.getName());
			empDto.setPosition(emp.getPosition());
			empDto.setStatusCode(200);
			empDtoList.add(empDto);
		}
		return new ResponseEntity<List<EmployeeDto>>(empDtoList, HttpStatus.OK);
	}

	@GetMapping("/employee/{id}")
	public ResponseEntity<EmployeeDto> getEmployeeById(@PathVariable int id) {
		EmployeeDto empDto = new EmployeeDto();
		Optional<Employee> empById = empRepository.findById(id);
		if (empById.isEmpty())
			throw new ResourceNotFoundException("Employee not found for Id " + id);

		if (empById.get() != null) {
			Employee emp = empById.get();
			empDto.setAge(emp.getAge());
			empDto.setEmp_id(emp.getEmp_id());
			empDto.setName(emp.getName());
			empDto.setPosition(emp.getPosition());
			empDto.setStatusCode(200);
		}

		return new ResponseEntity<EmployeeDto>(empDto, HttpStatus.OK);
	}

	@PostMapping("/employee")
	public ResponseEntity<EmployeeDto> createEmployee(@RequestBody Employee employee) {
		Employee emp = empRepository.save(employee);
		EmployeeDto empDto = new EmployeeDto();
		empDto.setAge(emp.getAge());
		empDto.setEmp_id(emp.getEmp_id());
		empDto.setName(emp.getName());
		empDto.setPosition(emp.getPosition());
		empDto.setStatusCode(201);
		return new ResponseEntity<EmployeeDto>(empDto, HttpStatus.CREATED);
	}

	@DeleteMapping("/employee/{id}")
	public ResponseEntity<MsgDto> deleteById(@PathVariable int id) {

		empRepository.deleteById(id);

		MsgDto msg = new MsgDto();
		msg.setMsg("Employee of Id" + id + " delete successfully");
		msg.setStatusCode(200);
		return new ResponseEntity<MsgDto>(msg, HttpStatus.OK);
	}

	@PutMapping("/employee/{id}")
	public Employee updateById(@PathVariable int id, @RequestBody Employee emp) {

		Employee empById = empRepository.findById(id).get();

		if (empById != null) {
			empById.setAge(emp.getAge());
			empById.setName(emp.getName());
			empById.setPosition(emp.getPosition());
			empRepository.save(empById);
		}
		return empById;
	}

}
